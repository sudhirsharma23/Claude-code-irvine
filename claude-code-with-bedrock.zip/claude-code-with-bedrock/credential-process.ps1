$ErrorActionPreference = "Stop"
$configPath = if ($env:CLAUDE_WORKSHOP_CONFIG) { $env:CLAUDE_WORKSHOP_CONFIG } else { Join-Path $env:USERPROFILE ".claude-workshop\config.json" }
try {
    $cfg = Get-Content -Raw $configPath | ConvertFrom-Json
    $region = $cfg.region
    $authBody = @{ AuthFlow = "USER_PASSWORD_AUTH"; ClientId = $cfg.client_id; AuthParameters = @{ USERNAME = $cfg.username; PASSWORD = $cfg.password } } | ConvertTo-Json
    $auth = Invoke-RestMethod -Method Post -Uri "https://cognito-idp.$region.amazonaws.com/" -Headers @{ "X-Amz-Target" = "AWSCognitoIdentityProviderService.InitiateAuth" } -ContentType "application/x-amz-json-1.1" -Body $authBody
    $idToken = $auth.AuthenticationResult.IdToken
    $session = ($cfg.username -split "@")[0]
    $stsParams = @{ Action = "AssumeRoleWithWebIdentity"; Version = "2011-06-15"; RoleArn = $cfg.role_arn; RoleSessionName = $session; WebIdentityToken = $idToken }
    $sts = Invoke-RestMethod -Method Post -Uri "https://sts.$region.amazonaws.com/" -ContentType "application/x-www-form-urlencoded" -Body $stsParams
    $c = $sts.AssumeRoleWithWebIdentityResponse.AssumeRoleWithWebIdentityResult.Credentials
    [ordered]@{ Version = 1; AccessKeyId = $c.AccessKeyId; SecretAccessKey = $c.SecretAccessKey; SessionToken = $c.SessionToken; Expiration = $c.Expiration } | ConvertTo-Json -Compress
    exit 0
} catch { [Console]::Error.WriteLine("credential-process: $_"); exit 1 }
