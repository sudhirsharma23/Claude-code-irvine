$configPath = if ($env:CLAUDE_WORKSHOP_CONFIG) { $env:CLAUDE_WORKSHOP_CONFIG } else { Join-Path $env:USERPROFILE ".claude-workshop\config.json" }
try { $email = (Get-Content -Raw $configPath | ConvertFrom-Json).username } catch { $email = "unknown" }
[ordered]@{ "x-user-email" = $email; "x-user-id" = $email; "x-user-name" = $email } | ConvertTo-Json -Compress
