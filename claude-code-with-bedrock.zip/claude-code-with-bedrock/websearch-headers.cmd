@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0websearch-headers.ps1"
