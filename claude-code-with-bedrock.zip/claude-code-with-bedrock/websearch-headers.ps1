$ErrorActionPreference = "Stop"
$configPath = if ($env:CLAUDE_WORKSHOP_CONFIG) { $env:CLAUDE_WORKSHOP_CONFIG } else { Join-Path $env:USERPROFILE ".claude-workshop\config.json" }
try {
    $cfg = Get-Content -Raw $configPath | ConvertFrom-Json
    $authBody = @{ AuthFlow = "USER_PASSWORD_AUTH"; ClientId = $cfg.client_id; AuthParameters = @{ USERNAME = $cfg.username; PASSWORD = $cfg.password } } | ConvertTo-Json
    $auth = Invoke-RestMethod -Method Post -Uri "https://cognito-idp.$($cfg.region).amazonaws.com/" -Headers @{ "X-Amz-Target" = "AWSCognitoIdentityProviderService.InitiateAuth" } -ContentType "application/x-amz-json-1.1" -Body $authBody
    $token = $auth.AuthenticationResult.AccessToken
    [ordered]@{ Authorization = "Bearer $token" } | ConvertTo-Json -Compress
    exit 0
} catch { [Console]::Error.WriteLine("websearch-headers: $_"); exit 1 }
