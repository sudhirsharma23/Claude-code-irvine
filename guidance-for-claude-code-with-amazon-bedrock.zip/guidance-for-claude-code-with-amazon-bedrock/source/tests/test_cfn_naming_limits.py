# ABOUTME: Static analysis tests ensuring CF templates don't use explicit resource names that exceed AWS limits
# ABOUTME: Prevents regression of issue #86 (target group name >32 chars)

"""CloudFormation resource naming limit tests.

Ensures that CF templates don't use explicit Name properties on resources
with strict AWS character limits. CloudFormation auto-generates names that
respect limits when Name is omitted.

Bug this prevents:
- #86: Target group name exceeded 32 chars because it used ${AWS::StackName}-tg
  and the monitoring stack name is {identity_pool_name}-otel-collector (already 31+ chars)
"""

import pytest

from tests.cfn_yaml import INFRA_DIR, iter_templates, load_resolved

# AWS resource types with strict naming limits
RESOURCE_NAME_LIMITS = {
    "AWS::ElasticLoadBalancingV2::TargetGroup": 32,
}

# Resources where explicit naming causes replace/AlreadyExists on stack updates.
# ALB Name: condition-dependent values trigger ALB replacement (create-and-replace semantics).
# ECS ServiceName: conditional logical IDs sharing a name cause AlreadyExists — CloudFormation
# creates the new resource before deleting the old.
RESOURCES_NO_EXPLICIT_NAME = {
    "AWS::ElasticLoadBalancingV2::LoadBalancer": "Name",
    "AWS::ECS::Service": "ServiceName",
}

OTEL_COLLECTOR_TEMPLATE = INFRA_DIR / "otel-collector.yaml"


def _get_all_cf_templates():
    """Get all CloudFormation YAML templates."""
    if not INFRA_DIR.exists():
        pytest.skip("deployment/infrastructure/ not found")
    return iter_templates()


class TestCFResourceNamingLimits:
    """Ensure CF templates don't use explicit Name on length-limited resources."""

    @pytest.fixture
    def templates(self):
        templates = _get_all_cf_templates()
        if not templates:
            pytest.skip("No CF templates found")
        return templates

    def test_no_stack_name_derived_target_group_name(self, templates):
        """Target groups must NOT derive Name from ${AWS::StackName} (32-char overflow).

        With stack names like 'claude-code-auth-otel-collector' (31 chars),
        any suffix pushes past 32. Names derived from other sources (e.g. an
        ALB's unique hex ID via !Sub) are acceptable when provably within limits.

        Allowed: !Sub with resource-ID references (bounded length, no StackName).
        Forbidden: plain strings or !Sub '${AWS::StackName}-*' patterns.
        """
        violations = []
        for template_path in templates:
            doc = load_resolved(template_path)

            if not doc or "Resources" not in doc:
                continue

            for logical_id, resource in doc["Resources"].items():
                if not isinstance(resource, dict):
                    continue
                rtype = resource.get("Type", "")
                if rtype not in RESOURCE_NAME_LIMITS:
                    continue
                props = resource.get("Properties", {})
                if not isinstance(props, dict) or "Name" not in props:
                    continue

                name_val = props["Name"]
                # Allow intrinsic-function-derived names (!Sub, !Join, etc.)
                # that do NOT reference AWS::StackName. load_resolved yields
                # these as lists (sequence nodes) or dicts (mapping nodes).
                # The dangerous pattern is ${AWS::StackName} which can overflow.
                if isinstance(name_val, (list, dict)):
                    # Check the template string for StackName references
                    template_str = name_val[0] if isinstance(name_val, list) else str(name_val)
                    if "${AWS::StackName}" not in str(template_str):
                        continue
                # Plain string Name or stack-name-derived — flag it
                violations.append(
                    f"{template_path.name}:{logical_id} ({rtype}) has explicit Name "
                    f"that may exceed {RESOURCE_NAME_LIMITS[rtype]} chars "
                    f"— use a bounded derivation or let CloudFormation auto-generate"
                )

        assert not violations, "CF templates have unsafe explicit Name on length-limited resources:\n" + "\n".join(
            f"  • {v}" for v in violations
        )

    def test_otel_collector_no_hardcoded_names(self):
        """otel-collector.yaml must not have explicit ALB Name or ECS ServiceName.

        ALB Name with conditional values triggers ALB replacement on condition toggle.
        ECS ServiceName on conditional resources causes AlreadyExists — CloudFormation
        creates the new resource before deleting the old when logical IDs change.
        """
        if not OTEL_COLLECTOR_TEMPLATE.exists():
            pytest.skip("otel-collector.yaml not found")

        doc = load_resolved(OTEL_COLLECTOR_TEMPLATE)

        violations = []
        for logical_id, resource in doc["Resources"].items():
            if not isinstance(resource, dict):
                continue
            rtype = resource.get("Type", "")
            if rtype in RESOURCES_NO_EXPLICIT_NAME:
                prop_name = RESOURCES_NO_EXPLICIT_NAME[rtype]
                props = resource.get("Properties", {})
                if isinstance(props, dict) and prop_name in props:
                    violations.append(f"{logical_id} ({rtype}) has explicit {prop_name}")

        assert not violations, "otel-collector.yaml has hardcoded names that break stack updates:\n" + "\n".join(
            f"  • {v}" for v in violations
        )

    def test_stack_name_suffix_inventory(self):
        """Document all ${AWS::StackName}-* patterns to track overflow risk.

        This test doesn't fail — it's a documentation/inventory test that
        surfaces all stack-name-derived resource names for review.
        """
        patterns = []
        for template_path in _get_all_cf_templates():
            with open(template_path, encoding="utf-8") as f:
                content = f.read()
            import re

            matches = re.findall(r"\$\{AWS::StackName\}([^'\"}\s]+)", content)
            for suffix in set(matches):
                patterns.append((template_path.name, suffix))

        # Just verify we found patterns (sanity check)
        assert len(patterns) > 0, "Expected to find ${AWS::StackName} patterns"


class TestIdentityPoolNameOverflow:
    """Verify identity_pool_name + stack suffixes don't overflow resource limits."""

    # All stack suffixes used in deploy.py
    STACK_SUFFIXES = {
        "auth": "-stack",
        "networking": "-networking",
        "monitoring": "-otel-collector",
        "dashboard": "-dashboard",
        "cowork-dashboard": "-cowork-dashboard",
        "analytics": "-analytics",
        "s3bucket": "-s3bucket",
        "distribution": "-distribution",
        "quota": "-quota",
        "codebuild": "-codebuild",
    }

    def test_default_name_fits_all_stacks(self):
        """The default 'claude-code-auth' must work with all stack suffixes."""
        default_name = "claude-code-auth"
        for _, suffix in self.STACK_SUFFIXES.items():
            stack_name = f"{default_name}{suffix}"
            # CF stack name limit is 128
            assert len(stack_name) <= 128, (
                f"Default name + '{suffix}' = '{stack_name}' ({len(stack_name)} chars) exceeds CF stack name limit"
            )

    def test_max_validated_name_fits_all_stacks(self):
        """A 20-char name (max allowed by validation) must work with all stacks."""
        max_name = "a" * 20
        for _, suffix in self.STACK_SUFFIXES.items():
            stack_name = f"{max_name}{suffix}"
            assert len(stack_name) <= 128, f"20-char name + '{suffix}' = {len(stack_name)} chars exceeds limit"

    def test_no_target_group_overflow_with_max_name(self):
        """Even if someone re-adds a -tg suffix, 20-char name fits in 32.

        20 (name) + 15 (-otel-collector) + 3 (-tg) = 38 > 32
        This proves we MUST NOT re-add explicit target group names.
        """
        max_name = "a" * 20
        monitoring_stack = f"{max_name}-otel-collector"
        tg_name = f"{monitoring_stack}-tg"
        # This SHOULD overflow — proving the explicit Name must stay removed
        assert len(tg_name) > 32, (
            "If this passes at <=32, someone might think it's safe to re-add "
            "the explicit Name — update the max limit if this fails"
        )
