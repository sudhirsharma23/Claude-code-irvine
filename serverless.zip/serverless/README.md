# Task Tracker — Serverless on AWS

A fully serverless deployment of the Task Tracker using AWS CDK, Lambda, API Gateway, DynamoDB, S3, and CloudFront.

---

## Table of Contents

1. [What This Does](#1-what-this-does)
2. [Architecture at a Glance](#2-architecture-at-a-glance)
3. [What Changed From the Local App — and Why](#3-what-changed-from-the-local-app--and-why)
4. [Prerequisites](#4-prerequisites)
5. [One-Time Setup](#5-one-time-setup)
6. [Deploy](#6-deploy)
7. [Access the App](#7-access-the-app)
8. [How to Test the API](#8-how-to-test-the-api)
9. [Project Structure](#9-project-structure)
10. [How Each File Works](#10-how-each-file-works)
11. [Updating and Re-deploying](#11-updating-and-re-deploying)
12. [Destroy (Clean Up)](#12-destroy-clean-up)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. What This Does

This folder contains everything needed to deploy the Task Tracker as a serverless application on AWS. Once deployed, the app:

- Runs with **no server to manage** — AWS starts and stops compute automatically on each request
- Is **publicly accessible** from any browser via a CloudFront HTTPS URL
- **Scales automatically** — works for 1 user or 10,000 without any configuration change
- **Costs ~$0/month** at personal or small-team usage (covered by the AWS free tier)

---

## 2. Architecture at a Glance

```
Browser
  │
  └──▶ CloudFront (HTTPS, single domain, security headers)
            │
            ├── /             ──▶ S3 (index.html)
            │
            └── /api/*        ──▶ API Gateway (HTTP API)
                                      │
                              ┌───────┴────────┐
                        5 Lambda functions      │
                        (one per endpoint)      │
                              │                 │
                              └──▶ DynamoDB (Tasks table)
```

| Layer | AWS Service | Role |
|---|---|---|
| CDN / Entry point | CloudFront | HTTPS, edge caching, security headers, single domain |
| Frontend | S3 | Hosts `index.html` |
| API routing | API Gateway HTTP API | Routes HTTP requests to Lambda |
| Business logic | Lambda (Python 3.13) | Validates input, reads/writes DynamoDB |
| Database | DynamoDB | Serverless NoSQL, auto-scales, free tier |

---

## 3. What Changed From the Local App — and Why

The local app (`app.py`, `db.py`, `routes.py`) and this serverless version implement
the same features and return the same JSON responses. The business logic — validation
rules, HTTP status codes, field defaults — is identical. What changed is the
**plumbing** to fit the AWS serverless model.

---

### Change 1 — Flask replaced by Lambda (one function per endpoint)

**Local app:** A single Flask process runs continuously on port 5000. All five
routes live in one file (`routes.py`) and Flask's `@api.get`, `@api.post`
decorators wire them up.

**Serverless:** No running process. AWS starts a function only when a request
arrives, runs it in milliseconds, then stops it. Each route became its own Python
file:

| Flask route in `routes.py` | Lambda handler | File |
|---|---|---|
| `@api.get('/tasks')` | `handler(event, context)` | `list_tasks.py` |
| `@api.post('/tasks')` | `handler(event, context)` | `create_task.py` |
| `@api.get('/tasks/<id>')` | `handler(event, context)` | `get_task.py` |
| `@api.put('/tasks/<id>')` | `handler(event, context)` | `update_task.py` |
| `@api.delete('/tasks/<id>')` | `handler(event, context)` | `delete_task.py` |

---

### Change 2 — How a request arrives

**Local app — Flask provides a `request` object:**
```python
status   = request.args.get('status')       # query param
data     = request.get_json(silent=True)    # JSON body
# task_id comes from the route decorator: def get_task(id)
```

**Serverless — API Gateway passes an `event` dict:**
```python
status   = (event.get('queryStringParameters') or {}).get('status')
data     = json.loads(event.get('body') or '{}')
task_id  = (event.get('pathParameters') or {}).get('id')
```

API Gateway wraps the HTTP request into a plain Python dict and passes it as the
first argument to `handler(event, context)`. There is no Flask, no `request`
global — just a dict.

---

### Change 3 — How a response is returned

**Local app — Flask returns a tuple:**
```python
return jsonify(tasks), 200
return jsonify({"error": "not found"}), 404
```

**Serverless — Lambda must return a specific dict:**
```python
return {
    "statusCode": 200,
    "headers": {"Content-Type": "application/json"},
    "body": json.dumps(tasks)   # body must always be a string, never a dict
}
```

API Gateway reads the `statusCode`, `headers`, and `body` fields and converts
them back into a real HTTP response. The `respond()` helper in `utils.py` builds
this dict so every handler just calls `respond(200, tasks)` — the same brevity as
Flask's `jsonify`.

---

### Change 4 — SQLite replaced by DynamoDB

This is the most significant logic change. SQLite is a file on disk. Lambda
functions are stateless and may run on different servers — there is no shared
filesystem, so `tasks.db` cannot exist.

DynamoDB is a network database that all Lambda functions connect to.

| Concern | Local SQLite (`db.py`) | Serverless DynamoDB (`functions/`) |
|---|---|---|
| **Connect** | `sqlite3.connect("tasks.db")` | `boto3.resource('dynamodb').Table(TABLE_NAME)` |
| **Task IDs** | `INTEGER PRIMARY KEY AUTOINCREMENT` | UUID string (`str(uuid.uuid4())`) |
| **Create** | `INSERT INTO tasks ...` | `table.put_item(Item={...})` |
| **Read one** | `SELECT * FROM tasks WHERE id = ?` | `table.get_item(Key={'id': id})` |
| **Filter list** | `SELECT * FROM tasks WHERE status = ?` | `table.query(IndexName='StatusIndex', ...)` |
| **Partial update** | `UPDATE tasks SET status=? WHERE id=?` | `table.update_item(UpdateExpression=...)` |
| **Detect missing row** | `rowcount == 0` | `ConditionExpression='attribute_exists(id)'` → raises `ConditionalCheckFailedException` |
| **Delete** | `DELETE FROM tasks WHERE id = ?` | `table.delete_item(Key={'id': id}, ConditionExpression=...)` |

**Why UUIDs instead of integers?**
SQLite's auto-increment uses a single counter in one file. DynamoDB is distributed
across many servers with no shared counter. A UUID is generated locally by the
Lambda function before writing — no coordination needed, no conflicts.

**Why GSIs (Global Secondary Indexes) for filtering?**
SQL can run `WHERE status = 'done'` by scanning all rows. DynamoDB's fast path
requires a key-based lookup. Two GSIs pre-index the data:

- `StatusIndex` — partition key: `status`, sort key: `created_at`
  → `GET /api/tasks?status=done` becomes a DynamoDB `Query` instead of a full scan
- `PriorityIndex` — partition key: `priority`, sort key: `created_at`
  → `GET /api/tasks?priority=high` same benefit

---

### Change 5 — `app.py` replaced by CDK stack

**Local app:** `app.py` wires Flask together (registers the blueprint, calls
`init_db()`, serves `index.html`). You start it with `python app.py`.

**Serverless:** `serverless/cdk/lib/task-tracker-stack.ts` defines every AWS
resource in TypeScript. Running `cdk deploy` reads this file and creates
everything in AWS automatically:

```
app.py  →  task-tracker-stack.ts
            ├── DynamoDB table (replaces tasks.db + init_db())
            ├── 5 Lambda functions (replace Flask routes)
            ├── API Gateway HTTP API (replaces Flask's routing)
            ├── S3 bucket (replaces send_from_directory)
            └── CloudFront distribution (new — not in the local app)
```

---

### Change 6 — Frontend (index.html) is unchanged

The file `static/index.html` is **not modified**. It still makes the same API
calls to `/api/tasks` using relative URLs. Because CloudFront routes `/api/*` to
API Gateway under the same domain, the browser sees it all as the same origin —
no CORS configuration needed in the frontend.

---

### Summary

| Concern | Local Flask app | Serverless |
|---|---|---|
| Runs as | Persistent process (`python app.py`) | On-demand function per request |
| Framework | Flask | None — plain Python + boto3 |
| Request input | `flask.request` object | `event` dict from API Gateway |
| Response output | `jsonify(...), 200` | `{"statusCode": 200, "body": "..."}` |
| Database | SQLite file (`tasks.db`) | DynamoDB table (network service) |
| Task IDs | Integer (auto-increment) | UUID string |
| Filtering | SQL `WHERE` clause | DynamoDB GSI query |
| Detect missing row | `rowcount == 0` | `ConditionalCheckFailedException` |
| Frontend served by | Flask (`send_from_directory`) | S3 + CloudFront |
| Infrastructure defined in | Nothing (just `python app.py`) | CDK TypeScript stack |
| Business logic / validation | Identical | Identical |
| HTTP status codes | Identical | Identical |
| JSON response shapes | Identical | Identical |
| `index.html` frontend | Original file | Same file, no changes |

---

## 5. Prerequisites

Before deploying, check that you have:

| Tool | Check command | Install if missing |
|---|---|---|
| AWS CLI | `aws --version` | Included in this environment |
| AWS credentials | `aws sts get-caller-identity --profile workshop` | Update `~/.claude-workshop/config.json` |
| Node.js 18+ | `node --version` | Already installed (v22) |
| AWS CDK | `npx cdk --version` | Installed in `serverless/cdk/node_modules` |

**Verify credentials work before continuing:**

```powershell
aws sts get-caller-identity --profile workshop
```

Expected output:
```json
{
    "UserId": "AROA...",
    "Account": "114386940075",
    "Arn": "arn:aws:iam::114386940075:role/WorkshopBedrockAccessRole"
}
```

If you see `NotAuthorizedException`, update the password in `C:\Users\Administrator\.claude-workshop\config.json` with fresh credentials from the workshop portal, then retry.

---

## 6. One-Time Setup

### 4a. Install npm dependencies

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
npm install
```

### 4b. Bootstrap CDK (run once per AWS account/region)

CDK needs a small toolkit stack in your AWS account the first time it deploys.

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk bootstrap
```

Output when successful:
```
✅  Environment aws://114386940075/us-east-1 bootstrapped.
```

You only need to run this once. Skip it on future deployments.

---

## 7. Deploy

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

CDK will show a summary of resources it is about to create and ask for confirmation:

```
Do you wish to deploy these changes (y/n)? y
```

Type `y` and press Enter. Deployment takes **3–5 minutes**.

### What gets created

| Resource | Type | Purpose |
|---|---|---|
| `TasksTable` | DynamoDB table | Stores all tasks |
| `ListTasksFn` | Lambda function | GET /api/tasks |
| `CreateTaskFn` | Lambda function | POST /api/tasks |
| `GetTaskFn` | Lambda function | GET /api/tasks/{id} |
| `UpdateTaskFn` | Lambda function | PUT /api/tasks/{id} |
| `DeleteTaskFn` | Lambda function | DELETE /api/tasks/{id} |
| `HttpApi` | API Gateway HTTP API | Routes requests to Lambda |
| `FrontendBucket` | S3 bucket | Hosts index.html |
| `Distribution` | CloudFront distribution | CDN, single HTTPS entry point |

### Deployment output

When complete, CDK prints the URLs:

```
Outputs:
TaskTrackerStack.AppUrl          = https://d1abc123xyz.cloudfront.net
TaskTrackerStack.ApiGatewayUrl   = https://abc123def.execute-api.us-east-1.amazonaws.com/
TaskTrackerStack.DynamoTableName = TaskTrackerStack-TasksTable1234ABCD-XYZ
```

---

## 8. Access the App

Open **`AppUrl`** from the deployment output in your browser:

```
https://d1abc123xyz.cloudfront.net
```

> **Note:** CloudFront propagates globally after the first deploy. It is usually accessible within 60 seconds of the deploy completing. If you see a 403 or blank page immediately after deploying, wait 1 minute and refresh.

The app works exactly like the local version — add tasks, mark them done, filter, delete — except it now runs on AWS and is accessible from any device on the internet.

---

## 9. How to Test the API

You can call the API directly using `curl` (bypassing CloudFront) with the `ApiGatewayUrl` from the deployment output.

Replace `API_URL` with your actual value from the deploy output.

```powershell
$API = "https://abc123def.execute-api.us-east-1.amazonaws.com"
```

**List all tasks:**
```powershell
curl "$API/api/tasks"
```

**Create a task:**
```powershell
curl -X POST "$API/api/tasks" `
  -H "Content-Type: application/json" `
  -d '{"title":"Buy milk","priority":"low","due_date":"2026-12-01"}'
```

**Get one task (replace ID with one from the create response):**
```powershell
curl "$API/api/tasks/TASK-UUID-HERE"
```

**Mark a task done:**
```powershell
curl -X PUT "$API/api/tasks/TASK-UUID-HERE" `
  -H "Content-Type: application/json" `
  -d '{"status":"done"}'
```

**Delete a task:**
```powershell
curl -X DELETE "$API/api/tasks/TASK-UUID-HERE"
```

**Filter by status:**
```powershell
curl "$API/api/tasks?status=open"
curl "$API/api/tasks?status=done"
curl "$API/api/tasks?priority=high"
```

---

## 10. Project Structure

```
serverless/
│
├── README.md                        This file
│
├── cdk/                             AWS CDK infrastructure (TypeScript)
│   ├── bin/
│   │   └── app.ts                   CDK app entry point
│   ├── lib/
│   │   └── task-tracker-stack.ts    All AWS resources defined here
│   ├── package.json                 CDK dependencies
│   ├── tsconfig.json                TypeScript config
│   └── cdk.json                     CDK toolkit config
│
└── functions/                       Lambda function handlers (Python 3.13)
    ├── utils.py                     Shared: validation, response helper, body parser
    ├── list_tasks.py                GET /api/tasks
    ├── create_task.py               POST /api/tasks
    ├── get_task.py                  GET /api/tasks/{id}
    ├── update_task.py               PUT /api/tasks/{id}
    └── delete_task.py               DELETE /api/tasks/{id}
```

---

## 11. How Each File Works

### `cdk/lib/task-tracker-stack.ts` — the entire infrastructure

This single TypeScript file defines every AWS resource the app needs. CDK reads this file and translates it into AWS CloudFormation, which creates all the resources.

**DynamoDB table:**
```
Partition key: id (UUID string)
GSI StatusIndex:  PK=status,   SK=created_at  → fast filter by status
GSI PriorityIndex: PK=priority, SK=created_at → fast filter by priority
Billing: PAY_PER_REQUEST (scales to zero, no idle cost)
```

**Lambda functions:**
Each function is created with:
- `runtime: PYTHON_3_13` — matches the existing local codebase
- `code: fromAsset('../functions')` — CDK zips the entire `functions/` folder and uploads it
- `environment: { TABLE_NAME: ... }` — the table name is injected as an environment variable so the code doesn't hardcode it
- `tracing: ACTIVE` — X-Ray tracing enabled automatically
- An IAM execution role with the minimum DynamoDB permissions needed

**API Gateway:**
HTTP API (v2) with five routes pointing to the five Lambda functions. CORS is configured to allow calls from any origin (safe because all API calls come through CloudFront in practice).

**CloudFront distribution:**
Two behaviors on one distribution:
- `/api/*` → API Gateway (caching disabled, all HTTP methods forwarded)
- `*` (default) → S3 (caching enabled, 24-hour TTL)

Also applies a **Response Headers Policy** that adds:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Strict-Transport-Security` (HTTPS only, 1 year)
- `Content-Security-Policy` (restricts script sources)
- `Referrer-Policy`

---

### `functions/utils.py` — shared helpers

Three functions used by all Lambda handlers:

| Function | What it does |
|---|---|
| `respond(status_code, body)` | Builds the Lambda proxy response dict (statusCode, headers, JSON body) |
| `validate_fields(data, require_title)` | Checks title non-empty, priority/status enums, due_date format. Returns list of error strings. |
| `parse_body(event)` | Parses the JSON request body from the Lambda event. Returns `(data, None)` on success or `(None, error_response)` on failure. |

---

### `functions/list_tasks.py` — GET /api/tasks

1. Reads `?status=` and `?priority=` from `event['queryStringParameters']`
2. Validates both values against allowed enums → 400 if invalid
3. If `status` filter: queries `StatusIndex` GSI (sorted newest first)
4. If `priority` filter: queries `PriorityIndex` GSI (sorted newest first)
5. If no filter: scans the whole table, sorts by `created_at` descending
6. Returns the list as JSON → 200

---

### `functions/create_task.py` — POST /api/tasks

1. Parses JSON body → 400 if invalid JSON or not an object
2. Validates fields (title required, enums, date format) → 400 if errors
3. Generates a UUID for the task ID (`str(uuid.uuid4())`)
4. Sets `created_at` to current UTC time (`datetime.now(timezone.utc)`)
5. Calls `table.put_item()` to write to DynamoDB
6. Returns the full task object → 201

---

### `functions/get_task.py` — GET /api/tasks/{id}

1. Reads `id` from `event['pathParameters']`
2. Calls `table.get_item(Key={'id': id})`
3. If item is `None` → 404
4. Returns item → 200

---

### `functions/update_task.py` — PUT /api/tasks/{id}

1. Reads `id` from path parameters
2. Parses JSON body → 400 if invalid
3. Validates only the fields that are present (partial update — fields not in the request body are not touched)
4. Builds a DynamoDB `UpdateExpression` dynamically:
   - `SET #title = :title, #status = :status` etc.
   - Uses expression attribute names (`#field`) to avoid reserved word conflicts
5. Uses `ConditionExpression = 'attribute_exists(id)'` — if the item doesn't exist, DynamoDB throws `ConditionalCheckFailedException` → returned as 404
6. Returns the full updated item → 200

---

### `functions/delete_task.py` — DELETE /api/tasks/{id}

1. Reads `id` from path parameters
2. Calls `table.delete_item()` with `ConditionExpression = 'attribute_exists(id)'`
3. If item didn't exist → `ConditionalCheckFailedException` → 404
4. Returns `{"deleted": true}` → 200

---

## 12. Updating and Re-deploying

### Change the frontend (index.html)

Edit `static/index.html` (in the root task-tracker folder), then re-deploy:

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

CDK detects that only the S3 content changed, uploads the new file, and invalidates the CloudFront cache. The updated page is live within ~30 seconds.

### Change a Lambda function

Edit any file in `serverless/functions/`, then re-deploy with `npx cdk deploy`. CDK re-zips the functions directory, creates a new Lambda deployment package, and updates the function.

### Change infrastructure (stack)

Edit `serverless/cdk/lib/task-tracker-stack.ts`, then re-deploy. CDK shows a diff of what changes before applying.

---

## 13. Destroy (Clean Up)

To delete everything this stack created in AWS (DynamoDB table, Lambda functions, API Gateway, S3 bucket, CloudFront distribution):

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk destroy
```

Type `y` when prompted. All resources and all task data are permanently deleted.

> The DynamoDB table is configured with `RemovalPolicy.DESTROY`, so it is deleted with the stack. If you want to keep the data, change this to `RemovalPolicy.RETAIN` in `task-tracker-stack.ts` before destroying.

---

## 14. Troubleshooting

### `NotAuthorizedException` when running `aws sts get-caller-identity`

Your workshop credentials have expired.

1. Get a fresh password from the workshop portal
2. Open `C:\Users\Administrator\.claude-workshop\config.json`
3. Update the `"password"` field
4. Retry `aws sts get-caller-identity --profile workshop`

---

### CloudFront returns 403 immediately after deploy

CloudFront takes up to 60 seconds to fully propagate. Wait 1 minute and refresh the browser.

---

### Lambda returns 500 (Internal Server Error)

Check the CloudWatch logs for the failing function:

```powershell
aws logs tail /aws/lambda/TaskTrackerStack-ListTasksFn --follow --profile workshop
```

Replace `ListTasksFn` with the name of whichever function is failing.

---

### `cdk deploy` fails with `ExpiredTokenException`

Your AWS session token has expired. Refresh credentials in `~/.claude-workshop/config.json` and retry.

---

### `Unable to resolve AWS account to use`

Make sure the profile is set:

```powershell
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

---

### CloudFront still shows old `index.html` after re-deploy

CDK automatically invalidates `/*` after a frontend deploy. If the old version persists past 2 minutes, force-invalidate manually:

```powershell
# Replace DISTRIBUTION_ID with the value from `cdk deploy` output or AWS Console
aws cloudfront create-invalidation `
  --distribution-id DISTRIBUTION_ID `
  --paths "/*" `
  --profile workshop
```
