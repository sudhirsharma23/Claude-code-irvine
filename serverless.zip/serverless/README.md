# Task Tracker — Serverless on AWS

A fully serverless deployment of the Task Tracker using AWS CDK, Lambda, API Gateway, DynamoDB, S3, and CloudFront.

---

## Table of Contents

1. [What This Does](#1-what-this-does)
2. [Architecture at a Glance](#2-architecture-at-a-glance)
3. [Prerequisites](#3-prerequisites)
4. [One-Time Setup](#4-one-time-setup)
5. [Deploy](#5-deploy)
6. [Access the App](#6-access-the-app)
7. [How to Test the API](#7-how-to-test-the-api)
8. [Project Structure](#8-project-structure)
9. [How Each File Works](#9-how-each-file-works)
10. [Updating and Re-deploying](#10-updating-and-re-deploying)
11. [Destroy (Clean Up)](#11-destroy-clean-up)
12. [Troubleshooting](#12-troubleshooting)

---

## 1. What This Does

This folder contains everything needed to deploy the Task Tracker as a serverless application on AWS. Once deployed, the app:

- Runs with **no server to manage** — AWS starts and stops compute automatically on each request
- Is **publicly accessible** from any browser via a CloudFront HTTPS URL
- **Scales automatically** — works for 1 user or 10,000 without any configuration change
- **Costs ~$0/month** at personal or small-team usage (covered by the AWS free tier)

---

## 2. Architecture at a Glance

```
Browser
  │
  └──▶ CloudFront (HTTPS, single domain, security headers)
            │
            ├── /             ──▶ S3 (index.html)
            │
            └── /api/*        ──▶ API Gateway (HTTP API)
                                      │
                              ┌───────┴────────┐
                        5 Lambda functions      │
                        (one per endpoint)      │
                              │                 │
                              └──▶ DynamoDB (Tasks table)
```

| Layer | AWS Service | Role |
|---|---|---|
| CDN / Entry point | CloudFront | HTTPS, edge caching, security headers, single domain |
| Frontend | S3 | Hosts `index.html` |
| API routing | API Gateway HTTP API | Routes HTTP requests to Lambda |
| Business logic | Lambda (Python 3.13) | Validates input, reads/writes DynamoDB |
| Database | DynamoDB | Serverless NoSQL, auto-scales, free tier |

---

## 3. Prerequisites

Before deploying, check that you have:

| Tool | Check command | Install if missing |
|---|---|---|
| AWS CLI | `aws --version` | Included in this environment |
| AWS credentials | `aws sts get-caller-identity --profile workshop` | Update `~/.claude-workshop/config.json` |
| Node.js 18+ | `node --version` | Already installed (v22) |
| AWS CDK | `npx cdk --version` | Installed in `serverless/cdk/node_modules` |

**Verify credentials work before continuing:**

```powershell
aws sts get-caller-identity --profile workshop
```

Expected output:
```json
{
    "UserId": "AROA...",
    "Account": "114386940075",
    "Arn": "arn:aws:iam::114386940075:role/WorkshopBedrockAccessRole"
}
```

If you see `NotAuthorizedException`, update the password in `C:\Users\Administrator\.claude-workshop\config.json` with fresh credentials from the workshop portal, then retry.

---

## 4. One-Time Setup

### 4a. Install npm dependencies

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
npm install
```

### 4b. Bootstrap CDK (run once per AWS account/region)

CDK needs a small toolkit stack in your AWS account the first time it deploys.

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk bootstrap
```

Output when successful:
```
✅  Environment aws://114386940075/us-east-1 bootstrapped.
```

You only need to run this once. Skip it on future deployments.

---

## 5. Deploy

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

CDK will show a summary of resources it is about to create and ask for confirmation:

```
Do you wish to deploy these changes (y/n)? y
```

Type `y` and press Enter. Deployment takes **3–5 minutes**.

### What gets created

| Resource | Type | Purpose |
|---|---|---|
| `TasksTable` | DynamoDB table | Stores all tasks |
| `ListTasksFn` | Lambda function | GET /api/tasks |
| `CreateTaskFn` | Lambda function | POST /api/tasks |
| `GetTaskFn` | Lambda function | GET /api/tasks/{id} |
| `UpdateTaskFn` | Lambda function | PUT /api/tasks/{id} |
| `DeleteTaskFn` | Lambda function | DELETE /api/tasks/{id} |
| `HttpApi` | API Gateway HTTP API | Routes requests to Lambda |
| `FrontendBucket` | S3 bucket | Hosts index.html |
| `Distribution` | CloudFront distribution | CDN, single HTTPS entry point |

### Deployment output

When complete, CDK prints the URLs:

```
Outputs:
TaskTrackerStack.AppUrl          = https://d1abc123xyz.cloudfront.net
TaskTrackerStack.ApiGatewayUrl   = https://abc123def.execute-api.us-east-1.amazonaws.com/
TaskTrackerStack.DynamoTableName = TaskTrackerStack-TasksTable1234ABCD-XYZ
```

---

## 6. Access the App

Open **`AppUrl`** from the deployment output in your browser:

```
https://d1abc123xyz.cloudfront.net
```

> **Note:** CloudFront propagates globally after the first deploy. It is usually accessible within 60 seconds of the deploy completing. If you see a 403 or blank page immediately after deploying, wait 1 minute and refresh.

The app works exactly like the local version — add tasks, mark them done, filter, delete — except it now runs on AWS and is accessible from any device on the internet.

---

## 7. How to Test the API

You can call the API directly using `curl` (bypassing CloudFront) with the `ApiGatewayUrl` from the deployment output.

Replace `API_URL` with your actual value from the deploy output.

```powershell
$API = "https://abc123def.execute-api.us-east-1.amazonaws.com"
```

**List all tasks:**
```powershell
curl "$API/api/tasks"
```

**Create a task:**
```powershell
curl -X POST "$API/api/tasks" `
  -H "Content-Type: application/json" `
  -d '{"title":"Buy milk","priority":"low","due_date":"2026-12-01"}'
```

**Get one task (replace ID with one from the create response):**
```powershell
curl "$API/api/tasks/TASK-UUID-HERE"
```

**Mark a task done:**
```powershell
curl -X PUT "$API/api/tasks/TASK-UUID-HERE" `
  -H "Content-Type: application/json" `
  -d '{"status":"done"}'
```

**Delete a task:**
```powershell
curl -X DELETE "$API/api/tasks/TASK-UUID-HERE"
```

**Filter by status:**
```powershell
curl "$API/api/tasks?status=open"
curl "$API/api/tasks?status=done"
curl "$API/api/tasks?priority=high"
```

---

## 8. Project Structure

```
serverless/
│
├── README.md                        This file
│
├── cdk/                             AWS CDK infrastructure (TypeScript)
│   ├── bin/
│   │   └── app.ts                   CDK app entry point
│   ├── lib/
│   │   └── task-tracker-stack.ts    All AWS resources defined here
│   ├── package.json                 CDK dependencies
│   ├── tsconfig.json                TypeScript config
│   └── cdk.json                     CDK toolkit config
│
└── functions/                       Lambda function handlers (Python 3.13)
    ├── utils.py                     Shared: validation, response helper, body parser
    ├── list_tasks.py                GET /api/tasks
    ├── create_task.py               POST /api/tasks
    ├── get_task.py                  GET /api/tasks/{id}
    ├── update_task.py               PUT /api/tasks/{id}
    └── delete_task.py               DELETE /api/tasks/{id}
```

---

## 9. How Each File Works

### `cdk/lib/task-tracker-stack.ts` — the entire infrastructure

This single TypeScript file defines every AWS resource the app needs. CDK reads this file and translates it into AWS CloudFormation, which creates all the resources.

**DynamoDB table:**
```
Partition key: id (UUID string)
GSI StatusIndex:  PK=status,   SK=created_at  → fast filter by status
GSI PriorityIndex: PK=priority, SK=created_at → fast filter by priority
Billing: PAY_PER_REQUEST (scales to zero, no idle cost)
```

**Lambda functions:**
Each function is created with:
- `runtime: PYTHON_3_13` — matches the existing local codebase
- `code: fromAsset('../functions')` — CDK zips the entire `functions/` folder and uploads it
- `environment: { TABLE_NAME: ... }` — the table name is injected as an environment variable so the code doesn't hardcode it
- `tracing: ACTIVE` — X-Ray tracing enabled automatically
- An IAM execution role with the minimum DynamoDB permissions needed

**API Gateway:**
HTTP API (v2) with five routes pointing to the five Lambda functions. CORS is configured to allow calls from any origin (safe because all API calls come through CloudFront in practice).

**CloudFront distribution:**
Two behaviors on one distribution:
- `/api/*` → API Gateway (caching disabled, all HTTP methods forwarded)
- `*` (default) → S3 (caching enabled, 24-hour TTL)

Also applies a **Response Headers Policy** that adds:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Strict-Transport-Security` (HTTPS only, 1 year)
- `Content-Security-Policy` (restricts script sources)
- `Referrer-Policy`

---

### `functions/utils.py` — shared helpers

Three functions used by all Lambda handlers:

| Function | What it does |
|---|---|
| `respond(status_code, body)` | Builds the Lambda proxy response dict (statusCode, headers, JSON body) |
| `validate_fields(data, require_title)` | Checks title non-empty, priority/status enums, due_date format. Returns list of error strings. |
| `parse_body(event)` | Parses the JSON request body from the Lambda event. Returns `(data, None)` on success or `(None, error_response)` on failure. |

---

### `functions/list_tasks.py` — GET /api/tasks

1. Reads `?status=` and `?priority=` from `event['queryStringParameters']`
2. Validates both values against allowed enums → 400 if invalid
3. If `status` filter: queries `StatusIndex` GSI (sorted newest first)
4. If `priority` filter: queries `PriorityIndex` GSI (sorted newest first)
5. If no filter: scans the whole table, sorts by `created_at` descending
6. Returns the list as JSON → 200

---

### `functions/create_task.py` — POST /api/tasks

1. Parses JSON body → 400 if invalid JSON or not an object
2. Validates fields (title required, enums, date format) → 400 if errors
3. Generates a UUID for the task ID (`str(uuid.uuid4())`)
4. Sets `created_at` to current UTC time (`datetime.now(timezone.utc)`)
5. Calls `table.put_item()` to write to DynamoDB
6. Returns the full task object → 201

---

### `functions/get_task.py` — GET /api/tasks/{id}

1. Reads `id` from `event['pathParameters']`
2. Calls `table.get_item(Key={'id': id})`
3. If item is `None` → 404
4. Returns item → 200

---

### `functions/update_task.py` — PUT /api/tasks/{id}

1. Reads `id` from path parameters
2. Parses JSON body → 400 if invalid
3. Validates only the fields that are present (partial update — fields not in the request body are not touched)
4. Builds a DynamoDB `UpdateExpression` dynamically:
   - `SET #title = :title, #status = :status` etc.
   - Uses expression attribute names (`#field`) to avoid reserved word conflicts
5. Uses `ConditionExpression = 'attribute_exists(id)'` — if the item doesn't exist, DynamoDB throws `ConditionalCheckFailedException` → returned as 404
6. Returns the full updated item → 200

---

### `functions/delete_task.py` — DELETE /api/tasks/{id}

1. Reads `id` from path parameters
2. Calls `table.delete_item()` with `ConditionExpression = 'attribute_exists(id)'`
3. If item didn't exist → `ConditionalCheckFailedException` → 404
4. Returns `{"deleted": true}` → 200

---

## 10. Updating and Re-deploying

### Change the frontend (index.html)

Edit `static/index.html` (in the root task-tracker folder), then re-deploy:

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

CDK detects that only the S3 content changed, uploads the new file, and invalidates the CloudFront cache. The updated page is live within ~30 seconds.

### Change a Lambda function

Edit any file in `serverless/functions/`, then re-deploy with `npx cdk deploy`. CDK re-zips the functions directory, creates a new Lambda deployment package, and updates the function.

### Change infrastructure (stack)

Edit `serverless/cdk/lib/task-tracker-stack.ts`, then re-deploy. CDK shows a diff of what changes before applying.

---

## 11. Destroy (Clean Up)

To delete everything this stack created in AWS (DynamoDB table, Lambda functions, API Gateway, S3 bucket, CloudFront distribution):

```powershell
cd C:\Users\Administrator\task-tracker\serverless\cdk
$env:AWS_PROFILE = "workshop"
npx cdk destroy
```

Type `y` when prompted. All resources and all task data are permanently deleted.

> The DynamoDB table is configured with `RemovalPolicy.DESTROY`, so it is deleted with the stack. If you want to keep the data, change this to `RemovalPolicy.RETAIN` in `task-tracker-stack.ts` before destroying.

---

## 12. Troubleshooting

### `NotAuthorizedException` when running `aws sts get-caller-identity`

Your workshop credentials have expired.

1. Get a fresh password from the workshop portal
2. Open `C:\Users\Administrator\.claude-workshop\config.json`
3. Update the `"password"` field
4. Retry `aws sts get-caller-identity --profile workshop`

---

### CloudFront returns 403 immediately after deploy

CloudFront takes up to 60 seconds to fully propagate. Wait 1 minute and refresh the browser.

---

### Lambda returns 500 (Internal Server Error)

Check the CloudWatch logs for the failing function:

```powershell
aws logs tail /aws/lambda/TaskTrackerStack-ListTasksFn --follow --profile workshop
```

Replace `ListTasksFn` with the name of whichever function is failing.

---

### `cdk deploy` fails with `ExpiredTokenException`

Your AWS session token has expired. Refresh credentials in `~/.claude-workshop/config.json` and retry.

---

### `Unable to resolve AWS account to use`

Make sure the profile is set:

```powershell
$env:AWS_PROFILE = "workshop"
npx cdk deploy
```

---

### CloudFront still shows old `index.html` after re-deploy

CDK automatically invalidates `/*` after a frontend deploy. If the old version persists past 2 minutes, force-invalidate manually:

```powershell
# Replace DISTRIBUTION_ID with the value from `cdk deploy` output or AWS Console
aws cloudfront create-invalidation `
  --distribution-id DISTRIBUTION_ID `
  --paths "/*" `
  --profile workshop
```
