import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigatewayv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as integrations from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as path from 'path';

export class TaskTrackerStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // -------------------------------------------------------------------------
    // DynamoDB — task storage
    // -------------------------------------------------------------------------
    const table = new dynamodb.Table(this, 'TasksTable', {
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      pointInTimeRecovery: true,
    });

    // Filter by status (e.g. GET /api/tasks?status=done)
    table.addGlobalSecondaryIndex({
      indexName: 'StatusIndex',
      partitionKey: { name: 'status', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'created_at', type: dynamodb.AttributeType.STRING },
    });

    // Filter by priority (e.g. GET /api/tasks?priority=high)
    table.addGlobalSecondaryIndex({
      indexName: 'PriorityIndex',
      partitionKey: { name: 'priority', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'created_at', type: dynamodb.AttributeType.STRING },
    });

    // -------------------------------------------------------------------------
    // Lambda — one function per API operation
    // -------------------------------------------------------------------------
    const functionDir = path.join(__dirname, '../../functions');

    const commonProps: Pick<lambda.FunctionProps, 'runtime' | 'code' | 'environment' | 'timeout' | 'tracing'> = {
      runtime: lambda.Runtime.PYTHON_3_13,
      code: lambda.Code.fromAsset(functionDir),
      environment: { TABLE_NAME: table.tableName },
      timeout: cdk.Duration.seconds(10),
      tracing: lambda.Tracing.ACTIVE,
    };

    const listFn = new lambda.Function(this, 'ListTasksFn', {
      ...commonProps,
      handler: 'list_tasks.handler',
      memorySize: 256,
      description: 'GET /api/tasks — list and filter tasks',
    });

    const createFn = new lambda.Function(this, 'CreateTaskFn', {
      ...commonProps,
      handler: 'create_task.handler',
      memorySize: 256,
      description: 'POST /api/tasks — create a task',
    });

    const getFn = new lambda.Function(this, 'GetTaskFn', {
      ...commonProps,
      handler: 'get_task.handler',
      memorySize: 128,
      timeout: cdk.Duration.seconds(5),
      description: 'GET /api/tasks/{id} — fetch one task',
    });

    const updateFn = new lambda.Function(this, 'UpdateTaskFn', {
      ...commonProps,
      handler: 'update_task.handler',
      memorySize: 256,
      description: 'PUT /api/tasks/{id} — partial update',
    });

    const deleteFn = new lambda.Function(this, 'DeleteTaskFn', {
      ...commonProps,
      handler: 'delete_task.handler',
      memorySize: 128,
      timeout: cdk.Duration.seconds(5),
      description: 'DELETE /api/tasks/{id} — delete a task',
    });

    // Least-privilege DynamoDB grants
    table.grantReadData(listFn);
    table.grantWriteData(createFn);
    table.grantReadData(getFn);
    table.grantReadWriteData(updateFn);
    table.grantWriteData(deleteFn);

    // -------------------------------------------------------------------------
    // API Gateway HTTP API (v2) — routes to Lambda
    // -------------------------------------------------------------------------
    const httpApi = new apigatewayv2.HttpApi(this, 'HttpApi', {
      apiName: 'task-tracker-api',
      description: 'Task Tracker REST API',
      corsPreflight: {
        allowHeaders: ['Content-Type', 'Authorization'],
        allowMethods: [apigatewayv2.CorsHttpMethod.ANY],
        allowOrigins: ['*'],
        maxAge: cdk.Duration.hours(1),
      },
    });

    const addRoute = (
      path: string,
      method: apigatewayv2.HttpMethod,
      fn: lambda.Function,
      integId: string,
    ) =>
      httpApi.addRoutes({
        path,
        methods: [method],
        integration: new integrations.HttpLambdaIntegration(integId, fn),
      });

    addRoute('/api/tasks',      apigatewayv2.HttpMethod.GET,    listFn,   'ListInteg');
    addRoute('/api/tasks',      apigatewayv2.HttpMethod.POST,   createFn, 'CreateInteg');
    addRoute('/api/tasks/{id}', apigatewayv2.HttpMethod.GET,    getFn,    'GetInteg');
    addRoute('/api/tasks/{id}', apigatewayv2.HttpMethod.PUT,    updateFn, 'UpdateInteg');
    addRoute('/api/tasks/{id}', apigatewayv2.HttpMethod.DELETE, deleteFn, 'DeleteInteg');

    // -------------------------------------------------------------------------
    // S3 — static frontend hosting
    // -------------------------------------------------------------------------
    const frontendBucket = new s3.Bucket(this, 'FrontendBucket', {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true,
    });

    // -------------------------------------------------------------------------
    // CloudFront — CDN, single entry point, security headers
    // -------------------------------------------------------------------------
    const oai = new cloudfront.OriginAccessIdentity(this, 'OAI');
    frontendBucket.grantRead(oai);

    const securityHeadersPolicy = new cloudfront.ResponseHeadersPolicy(this, 'SecurityHeaders', {
      securityHeadersBehavior: {
        contentTypeOptions: { override: true },
        frameOptions: { frameOption: cloudfront.HeadersFrameOption.DENY, override: true },
        referrerPolicy: {
          referrerPolicy: cloudfront.HeadersReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN,
          override: true,
        },
        strictTransportSecurity: {
          accessControlMaxAge: cdk.Duration.days(365),
          includeSubdomains: true,
          override: true,
        },
        contentSecurityPolicy: {
          contentSecurityPolicy:
            "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:;",
          override: true,
        },
      },
    });

    const apiDomain = `${httpApi.httpApiId}.execute-api.${this.region}.amazonaws.com`;

    const distribution = new cloudfront.Distribution(this, 'Distribution', {
      defaultRootObject: 'index.html',
      defaultBehavior: {
        origin: new origins.S3Origin(frontendBucket, { originAccessIdentity: oai }),
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        responseHeadersPolicy: securityHeadersPolicy,
      },
      additionalBehaviors: {
        '/api/*': {
          origin: new origins.HttpOrigin(apiDomain),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.HTTPS_ONLY,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          originRequestPolicy: cloudfront.OriginRequestPolicy.ALL_VIEWER_EXCEPT_HOST_HEADER,
          responseHeadersPolicy: securityHeadersPolicy,
        },
      },
      errorResponses: [
        { httpStatus: 403, responseHttpStatus: 200, responsePagePath: '/index.html' },
        { httpStatus: 404, responseHttpStatus: 200, responsePagePath: '/index.html' },
      ],
      minimumProtocolVersion: cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021,
    });

    // Upload index.html to S3 and invalidate CloudFront cache on deploy
    new s3deploy.BucketDeployment(this, 'DeployFrontend', {
      sources: [s3deploy.Source.asset(path.join(__dirname, '../../../static'))],
      destinationBucket: frontendBucket,
      distribution,
      distributionPaths: ['/*'],
    });

    // -------------------------------------------------------------------------
    // Outputs
    // -------------------------------------------------------------------------
    new cdk.CfnOutput(this, 'AppUrl', {
      value: `https://${distribution.distributionDomainName}`,
      description: 'Open this URL in your browser to use the Task Tracker',
    });

    new cdk.CfnOutput(this, 'ApiGatewayUrl', {
      value: httpApi.url ?? '',
      description: 'Direct API Gateway URL (for curl / testing)',
    });

    new cdk.CfnOutput(this, 'DynamoTableName', {
      value: table.tableName,
      description: 'DynamoDB table name',
    });
  }
}
