import os
import uuid
from datetime import datetime, timezone
import boto3
from utils import respond, validate_fields, parse_body

TABLE_NAME = os.environ['TABLE_NAME']
_dynamodb = boto3.resource('dynamodb')
_table = _dynamodb.Table(TABLE_NAME)


def handler(event, _context):
    data, err = parse_body(event)
    if err:
        return err

    errors = validate_fields(data, require_title=True)
    if errors:
        return respond(400, {'errors': errors})

    item = {
        'id': str(uuid.uuid4()),
        'title': str(data['title']).strip(),
        'description': str(data.get('description', '')),
        'priority': data.get('priority', 'medium'),
        'status': data.get('status', 'open'),
        'due_date': data.get('due_date'),
        'created_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
    }

    _table.put_item(Item=item)
    return respond(201, item)
