import os
import boto3
from botocore.exceptions import ClientError
from utils import respond

TABLE_NAME = os.environ['TABLE_NAME']
_dynamodb = boto3.resource('dynamodb')
_table = _dynamodb.Table(TABLE_NAME)


def handler(event, _context):
    task_id = (event.get('pathParameters') or {}).get('id')
    if not task_id:
        return respond(400, {'error': 'missing id'})

    try:
        _table.delete_item(
            Key={'id': task_id},
            ConditionExpression='attribute_exists(id)',
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return respond(404, {'error': 'task not found'})
        raise

    return respond(200, {'deleted': True})
