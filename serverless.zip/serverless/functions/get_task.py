import os
import boto3
from utils import respond

TABLE_NAME = os.environ['TABLE_NAME']
_dynamodb = boto3.resource('dynamodb')
_table = _dynamodb.Table(TABLE_NAME)


def handler(event, _context):
    task_id = (event.get('pathParameters') or {}).get('id')
    if not task_id:
        return respond(400, {'error': 'missing id'})

    result = _table.get_item(Key={'id': task_id})
    item = result.get('Item')
    if item is None:
        return respond(404, {'error': 'task not found'})

    return respond(200, item)
