import os
import boto3
from boto3.dynamodb.conditions import Key
from utils import respond, VALID_STATUSES, VALID_PRIORITIES

TABLE_NAME = os.environ['TABLE_NAME']
_dynamodb = boto3.resource('dynamodb')
_table = _dynamodb.Table(TABLE_NAME)


def handler(event, _context):
    params = event.get('queryStringParameters') or {}
    status = params.get('status')
    priority = params.get('priority')

    if status and status not in VALID_STATUSES:
        return respond(400, {'error': f"status must be one of: {', '.join(sorted(VALID_STATUSES))}"})
    if priority and priority not in VALID_PRIORITIES:
        return respond(400, {'error': f"priority must be one of: {', '.join(sorted(VALID_PRIORITIES))}"})

    if status:
        result = _table.query(
            IndexName='StatusIndex',
            KeyConditionExpression=Key('status').eq(status),
            ScanIndexForward=False,
        )
    elif priority:
        result = _table.query(
            IndexName='PriorityIndex',
            KeyConditionExpression=Key('priority').eq(priority),
            ScanIndexForward=False,
        )
    else:
        result = _table.scan()
        result['Items'].sort(key=lambda x: x.get('created_at', ''), reverse=True)

    return respond(200, result['Items'])
