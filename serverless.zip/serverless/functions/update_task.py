import os
import boto3
from botocore.exceptions import ClientError
from utils import respond, validate_fields, parse_body

TABLE_NAME = os.environ['TABLE_NAME']
_dynamodb = boto3.resource('dynamodb')
_table = _dynamodb.Table(TABLE_NAME)

ALLOWED = {'title', 'description', 'priority', 'status', 'due_date'}


def handler(event, _context):
    task_id = (event.get('pathParameters') or {}).get('id')
    if not task_id:
        return respond(400, {'error': 'missing id'})

    data, err = parse_body(event)
    if err:
        return err

    errors = validate_fields(data, require_title=False)
    if errors:
        return respond(400, {'errors': errors})

    fields = {k: v for k, v in data.items() if k in ALLOWED}
    if not fields:
        # Nothing to update — fetch and return current state
        result = _table.get_item(Key={'id': task_id})
        item = result.get('Item')
        if item is None:
            return respond(404, {'error': 'task not found'})
        return respond(200, item)

    # Build a DynamoDB UpdateItem expression
    set_parts = [f'#{k} = :{k}' for k in fields]
    update_expr = 'SET ' + ', '.join(set_parts)
    expr_names = {f'#{k}': k for k in fields}
    expr_values = {f':{k}': v for k, v in fields.items()}

    try:
        result = _table.update_item(
            Key={'id': task_id},
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
            ConditionExpression='attribute_exists(id)',
            ReturnValues='ALL_NEW',
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            return respond(404, {'error': 'task not found'})
        raise

    return respond(200, result['Attributes'])
