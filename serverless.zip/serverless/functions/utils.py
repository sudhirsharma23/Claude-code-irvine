import json
import re

VALID_PRIORITIES = {'low', 'medium', 'high'}
VALID_STATUSES = {'open', 'done'}
DATE_RE = re.compile(r'^\d{4}-\d{2}-\d{2}$')

CORS_HEADERS = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
}


def respond(status_code: int, body) -> dict:
    return {
        'statusCode': status_code,
        'headers': CORS_HEADERS,
        'body': json.dumps(body),
    }


def validate_fields(data: dict, require_title: bool = True) -> list[str]:
    errors = []

    if require_title:
        title = data.get('title', '')
        if not str(title).strip():
            errors.append('title is required and must be non-empty')
    elif 'title' in data:
        if not str(data['title']).strip():
            errors.append('title must be non-empty')

    if 'priority' in data and data['priority'] not in VALID_PRIORITIES:
        errors.append(f"priority must be one of: {', '.join(sorted(VALID_PRIORITIES))}")

    if 'status' in data and data['status'] not in VALID_STATUSES:
        errors.append(f"status must be one of: {', '.join(sorted(VALID_STATUSES))}")

    if 'due_date' in data and data['due_date'] is not None:
        if not DATE_RE.match(str(data['due_date'])):
            errors.append('due_date must be in YYYY-MM-DD format')

    return errors


def parse_body(event: dict) -> tuple[dict | None, dict | None]:
    """Return (data, error_response). One of them is always None."""
    raw = event.get('body') or '{}'
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None, respond(400, {'error': 'request body must be valid JSON'})
    if not isinstance(data, dict):
        return None, respond(400, {'error': 'request body must be a JSON object'})
    return data, None
