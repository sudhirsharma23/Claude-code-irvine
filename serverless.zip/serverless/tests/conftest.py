"""
Pytest fixtures for Lambda handler tests.
moto intercepts boto3 calls and routes them to an in-memory DynamoDB,
so no real AWS credentials or connection are needed.
"""
import os
import sys

# Put both the tests dir and the functions dir on sys.path before any local imports
_here = os.path.dirname(__file__)
sys.path.insert(0, _here)
sys.path.insert(0, os.path.join(_here, '..', 'functions'))

import pytest
import boto3
from moto import mock_aws
from helpers import TABLE_NAME, REGION


@pytest.fixture(scope='session', autouse=True)
def aws_credentials():
    """Fake credentials — prevents boto3 from calling real AWS."""
    os.environ['AWS_DEFAULT_REGION'] = REGION
    os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
    os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
    os.environ['AWS_SECURITY_TOKEN'] = 'testing'
    os.environ['AWS_SESSION_TOKEN'] = 'testing'
    os.environ['TABLE_NAME'] = TABLE_NAME


@pytest.fixture
def ddb_table(aws_credentials):
    """
    Fresh in-memory DynamoDB table for each test.
    moto's mock_aws context intercepts all boto3 DynamoDB calls.
    """
    with mock_aws():
        client = boto3.client('dynamodb', region_name=REGION)
        client.create_table(
            TableName=TABLE_NAME,
            KeySchema=[{'AttributeName': 'id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[
                {'AttributeName': 'id',         'AttributeType': 'S'},
                {'AttributeName': 'status',     'AttributeType': 'S'},
                {'AttributeName': 'priority',   'AttributeType': 'S'},
                {'AttributeName': 'created_at', 'AttributeType': 'S'},
            ],
            GlobalSecondaryIndexes=[
                {
                    'IndexName': 'StatusIndex',
                    'KeySchema': [
                        {'AttributeName': 'status',     'KeyType': 'HASH'},
                        {'AttributeName': 'created_at', 'KeyType': 'RANGE'},
                    ],
                    'Projection': {'ProjectionType': 'ALL'},
                },
                {
                    'IndexName': 'PriorityIndex',
                    'KeySchema': [
                        {'AttributeName': 'priority',   'KeyType': 'HASH'},
                        {'AttributeName': 'created_at', 'KeyType': 'RANGE'},
                    ],
                    'Projection': {'ProjectionType': 'ALL'},
                },
            ],
            BillingMode='PAY_PER_REQUEST',
        )
        yield boto3.resource('dynamodb', region_name=REGION).Table(TABLE_NAME)
