import json

TABLE_NAME = 'Tasks'
REGION = 'us-east-1'


def make_event(method='GET', path='/', path_params=None, query_params=None, body=None):
    """Build a minimal API Gateway Lambda proxy event."""
    return {
        'httpMethod': method,
        'path': path,
        'pathParameters': path_params or {},
        'queryStringParameters': query_params or {},
        'body': json.dumps(body) if body is not None else None,
        'headers': {'Content-Type': 'application/json'},
    }
