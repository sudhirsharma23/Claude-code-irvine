"""
Unit tests for all five Lambda handlers.
moto replaces boto3 with an in-memory DynamoDB — no AWS account needed.
"""
import json
import importlib
import pytest
from moto import mock_aws
from helpers import make_event, TABLE_NAME, REGION


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_handler(module_name: str):
    """Import a handler module fresh inside the moto mock context."""
    import sys
    # Force reimport so the module's module-level boto3 calls hit the mock
    if module_name in sys.modules:
        del sys.modules[module_name]
    return importlib.import_module(module_name)


def body(response: dict) -> dict:
    return json.loads(response['body'])


def create_task(ddb_table, **kwargs):
    """Helper: create a task via the handler and return the parsed response body."""
    with mock_aws():
        mod = load_handler('create_task')
        payload = {'title': 'Test task', **kwargs}
        resp = mod.handler(make_event('POST', '/api/tasks', body=payload), None)
        assert resp['statusCode'] == 201
        return body(resp)


# ---------------------------------------------------------------------------
# list_tasks — GET /api/tasks
# ---------------------------------------------------------------------------

class TestListTasks:
    def test_empty_returns_list(self, ddb_table):
        with mock_aws():
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(), None)
        assert resp['statusCode'] == 200
        assert body(resp) == []

    def test_returns_created_tasks(self, ddb_table):
        with mock_aws():
            # Seed two tasks directly into the mock table
            ddb_table.put_item(Item={'id': '1', 'title': 'A', 'status': 'open',
                                     'priority': 'medium', 'created_at': '2026-01-01T00:00:00Z'})
            ddb_table.put_item(Item={'id': '2', 'title': 'B', 'status': 'done',
                                     'priority': 'high',   'created_at': '2026-01-02T00:00:00Z'})
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(), None)
        assert resp['statusCode'] == 200
        assert len(body(resp)) == 2

    def test_filter_by_status_open(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': '1', 'title': 'Open',  'status': 'open',
                                     'priority': 'low', 'created_at': '2026-01-01T00:00:00Z'})
            ddb_table.put_item(Item={'id': '2', 'title': 'Done',  'status': 'done',
                                     'priority': 'low', 'created_at': '2026-01-02T00:00:00Z'})
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(query_params={'status': 'open'}), None)
        assert resp['statusCode'] == 200
        tasks = body(resp)
        assert all(t['status'] == 'open' for t in tasks)
        assert len(tasks) == 1

    def test_filter_by_priority_high(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': '1', 'title': 'Hi',  'status': 'open',
                                     'priority': 'high', 'created_at': '2026-01-01T00:00:00Z'})
            ddb_table.put_item(Item={'id': '2', 'title': 'Lo',  'status': 'open',
                                     'priority': 'low',  'created_at': '2026-01-02T00:00:00Z'})
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(query_params={'priority': 'high'}), None)
        assert resp['statusCode'] == 200
        tasks = body(resp)
        assert len(tasks) == 1
        assert tasks[0]['priority'] == 'high'

    def test_invalid_status_filter_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(query_params={'status': 'pending'}), None)
        assert resp['statusCode'] == 400
        assert 'error' in body(resp)

    def test_invalid_priority_filter_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('list_tasks')
            resp = mod.handler(make_event(query_params={'priority': 'urgent'}), None)
        assert resp['statusCode'] == 400


# ---------------------------------------------------------------------------
# create_task — POST /api/tasks
# ---------------------------------------------------------------------------

class TestCreateTask:
    def test_happy_path_all_fields(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={
                'title': 'Full task',
                'description': 'Details here',
                'priority': 'high',
                'status': 'open',
                'due_date': '2026-12-31',
            }), None)
        assert resp['statusCode'] == 201
        data = body(resp)
        assert data['title'] == 'Full task'
        assert data['description'] == 'Details here'
        assert data['priority'] == 'high'
        assert data['status'] == 'open'
        assert data['due_date'] == '2026-12-31'
        assert 'id' in data
        assert 'created_at' in data

    def test_title_only_applies_defaults(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'title': 'Minimal'}), None)
        assert resp['statusCode'] == 201
        data = body(resp)
        assert data['priority'] == 'medium'
        assert data['status'] == 'open'
        assert data.get('due_date') is None

    def test_missing_title_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'description': 'no title'}), None)
        assert resp['statusCode'] == 400

    def test_blank_title_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'title': '   '}), None)
        assert resp['statusCode'] == 400

    def test_invalid_priority_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'title': 'T', 'priority': 'urgent'}), None)
        assert resp['statusCode'] == 400

    def test_invalid_status_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'title': 'T', 'status': 'pending'}), None)
        assert resp['statusCode'] == 400

    def test_invalid_due_date_format_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            resp = mod.handler(make_event('POST', body={'title': 'T', 'due_date': '31-12-2026'}), None)
        assert resp['statusCode'] == 400

    def test_non_json_body_returns_400(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            event = make_event('POST', body=None)
            event['body'] = 'not json at all'
            resp = mod.handler(event, None)
        assert resp['statusCode'] == 400

    def test_each_task_gets_unique_id(self, ddb_table):
        with mock_aws():
            mod = load_handler('create_task')
            r1 = mod.handler(make_event('POST', body={'title': 'Task 1'}), None)
            r2 = mod.handler(make_event('POST', body={'title': 'Task 2'}), None)
        assert body(r1)['id'] != body(r2)['id']


# ---------------------------------------------------------------------------
# get_task — GET /api/tasks/{id}
# ---------------------------------------------------------------------------

class TestGetTask:
    def test_existing_task_returns_200(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'abc', 'title': 'Find me', 'status': 'open',
                                     'priority': 'low', 'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('get_task')
            resp = mod.handler(make_event(path_params={'id': 'abc'}), None)
        assert resp['statusCode'] == 200
        assert body(resp)['title'] == 'Find me'

    def test_nonexistent_id_returns_404(self, ddb_table):
        with mock_aws():
            mod = load_handler('get_task')
            resp = mod.handler(make_event(path_params={'id': 'does-not-exist'}), None)
        assert resp['statusCode'] == 404
        assert 'error' in body(resp)


# ---------------------------------------------------------------------------
# update_task — PUT /api/tasks/{id}
# ---------------------------------------------------------------------------

class TestUpdateTask:
    def test_partial_update_only_changes_given_fields(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'u1', 'title': 'Old title', 'description': 'keep',
                                     'status': 'open', 'priority': 'low',
                                     'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('update_task')
            resp = mod.handler(make_event(path_params={'id': 'u1'},
                                          body={'title': 'New title'}), None)
        assert resp['statusCode'] == 200
        data = body(resp)
        assert data['title'] == 'New title'
        assert data['description'] == 'keep'
        assert data['status'] == 'open'

    def test_toggle_status_open_to_done(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'u2', 'title': 'T', 'status': 'open',
                                     'priority': 'medium', 'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('update_task')
            resp = mod.handler(make_event(path_params={'id': 'u2'},
                                          body={'status': 'done'}), None)
        assert resp['statusCode'] == 200
        assert body(resp)['status'] == 'done'

    def test_invalid_priority_returns_400(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'u3', 'title': 'T', 'status': 'open',
                                     'priority': 'low', 'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('update_task')
            resp = mod.handler(make_event(path_params={'id': 'u3'},
                                          body={'priority': 'critical'}), None)
        assert resp['statusCode'] == 400

    def test_nonexistent_id_returns_404(self, ddb_table):
        with mock_aws():
            mod = load_handler('update_task')
            resp = mod.handler(make_event(path_params={'id': 'ghost'},
                                          body={'title': 'x'}), None)
        assert resp['statusCode'] == 404


# ---------------------------------------------------------------------------
# delete_task — DELETE /api/tasks/{id}
# ---------------------------------------------------------------------------

class TestDeleteTask:
    def test_existing_task_returns_deleted_true(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'd1', 'title': 'Delete me', 'status': 'open',
                                     'priority': 'low', 'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('delete_task')
            resp = mod.handler(make_event(path_params={'id': 'd1'}), None)
        assert resp['statusCode'] == 200
        assert body(resp) == {'deleted': True}

    def test_nonexistent_id_returns_404(self, ddb_table):
        with mock_aws():
            mod = load_handler('delete_task')
            resp = mod.handler(make_event(path_params={'id': 'ghost'}), None)
        assert resp['statusCode'] == 404

    def test_deleted_task_no_longer_in_table(self, ddb_table):
        with mock_aws():
            ddb_table.put_item(Item={'id': 'd2', 'title': 'Gone', 'status': 'open',
                                     'priority': 'low', 'created_at': '2026-01-01T00:00:00Z'})
            mod = load_handler('delete_task')
            mod.handler(make_event(path_params={'id': 'd2'}), None)
            # Verify the item is actually gone
            result = ddb_table.get_item(Key={'id': 'd2'})
        assert 'Item' not in result
