# Task Tracker — Full Technical & Business Guide

---

## Table of Contents

1. [What Was Built — Business View](#1-what-was-built--business-view)
2. [How the System Is Structured — Architecture Overview](#2-how-the-system-is-structured--architecture-overview)
3. [The Database (SQLite + db.py)](#3-the-database-sqlite--dbpy)
4. [The API (Flask + routes.py)](#4-the-api-flask--routespy)
5. [The Frontend (index.html)](#5-the-frontend-indexhtml)
6. [End-to-End Flow — What Happens When You Use the App](#6-end-to-end-flow--what-happens-when-you-use-the-app)
7. [The Test Suite (pytest)](#7-the-test-suite-pytest)
8. [How AI Agents Were Used to Build This](#8-how-ai-agents-were-used-to-build-this)
9. [Project File Map](#9-project-file-map)
10. [Setup & Running the App](#10-setup--running-the-app)

---

## 1. What Was Built — Business View

**Task Tracker** is a simple web application that lets a person or a small team manage a list of tasks. Think of it as a lightweight to-do list with a few extra fields that make it practical for real work.

### What a user can do

| Action | How |
|---|---|
| Add a new task | Fill in the form at the top of the page and click "Add Task" |
| See all tasks | They appear automatically as cards on the page |
| Filter tasks | Use the Status or Priority dropdowns to narrow the list |
| Mark a task done | Click "Mark Done" on any open task card |
| Reopen a task | Click "Reopen" on any done task card |
| Delete a task | Click "Delete" on any task card |

### What information is stored per task

| Field | What it means | Example |
|---|---|---|
| **Title** | A short name for the task | "Fix login bug" |
| **Description** | More detail about what needs doing | "Users get a 500 error when..." |
| **Priority** | How urgent it is — low, medium, or high | "high" |
| **Status** | Whether it is open (not done) or done | "open" |
| **Due date** | Optional deadline | "2026-12-01" |
| **Created at** | When the task was added (set automatically) | "2026-11-13T19:00:00Z" |

### Business value

- Zero infrastructure cost — runs on a single machine, no cloud database needed.
- No third-party services — your data stays on your own computer.
- Accessible from any browser on the same network — no installation needed for end users.

---

## 2. How the System Is Structured — Architecture Overview

The application follows a classic **three-layer architecture**:

```
Browser (index.html)
       │  HTTP requests (JSON)
       ▼
Flask Web Server (app.py + routes.py)
       │  Python function calls
       ▼
SQLite Database (db.py + tasks.db)
```

Each layer has one job:

- **Frontend** — what the user sees and clicks. It sends requests to the server and shows the responses.
- **API server** — receives requests, checks the data is valid, talks to the database, sends back results.
- **Database** — stores the tasks permanently on disk.

This separation means each layer can be understood, tested, and changed independently.

---

## 3. The Database (SQLite + db.py)

### What is SQLite?

SQLite is a database that lives in a single file on your computer — here it is `tasks.db` in the project folder. There is no separate database server to install or run. Python includes SQLite support in its standard library, so no extra software is needed.

### The tasks table

There is one table in the database called `tasks`. Every task is one row:

```sql
CREATE TABLE tasks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT    NOT NULL,
    description TEXT    NOT NULL DEFAULT '',
    priority    TEXT    NOT NULL DEFAULT 'medium',
    status      TEXT    NOT NULL DEFAULT 'open',
    due_date    TEXT,
    created_at  TEXT    NOT NULL
)
```

- `INTEGER PRIMARY KEY AUTOINCREMENT` — SQLite automatically assigns each new task a unique number (1, 2, 3, …). You never need to supply this yourself.
- `NOT NULL` — SQLite will refuse to save a row if that field is missing.
- `DEFAULT 'medium'` — if you do not supply a priority when creating a task, it defaults to medium.
- `due_date TEXT` — no `NOT NULL`, so it can be left empty (NULL).

### db.py — the data access layer

`db.py` is the only file that talks to the database. All other code calls functions in this file; nothing else ever writes SQL directly. This keeps database logic in one place and makes it easy to change later.

| Function | What it does |
|---|---|
| `get_db()` | Opens a connection to `tasks.db` and returns it. Sets `row_factory = sqlite3.Row` so results come back as dict-like objects instead of raw tuples. |
| `init_db()` | Runs the `CREATE TABLE IF NOT EXISTS` statement on startup. Safe to call every time — it only creates the table if it does not already exist. |
| `list_tasks(status, priority)` | Builds a `SELECT` query with optional `WHERE` filters and returns a list of task dicts. |
| `create_task(data)` | Inserts a new row, sets `created_at` to the current UTC time, and returns the full saved task (including the auto-assigned `id`). |
| `get_task(id)` | Fetches one row by its `id`. Returns `None` if not found. |
| `update_task(id, data)` | Updates only the fields present in `data` (partial update). If `data` has only `{"status": "done"}`, only the status column is changed — everything else is untouched. Returns `None` if the task does not exist. |
| `delete_task(id)` | Deletes the row and returns `True` if a row was actually deleted, `False` if no row with that `id` existed. |

### Why parameterized queries?

Notice the `?` placeholders in the SQL:

```python
conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
```

This is called a **parameterized query**. The database driver handles escaping the value safely. If raw string formatting were used instead (`f"WHERE id = {task_id}"`), an attacker could pass in a crafted value and run arbitrary SQL — a classic **SQL injection** attack. Parameterized queries prevent this entirely.

---

## 4. The API (Flask + routes.py)

### What is Flask?

Flask is a lightweight Python web framework. It listens for HTTP requests on a port (5000 by default), matches each request to a handler function, and sends back an HTTP response.

### app.py — the entry point

`app.py` contains the `create_app()` factory function:

1. Creates a Flask application instance.
2. Calls `init_db()` — ensures the database table exists before any request is handled.
3. Registers the `api` Blueprint (all the route handlers from `routes.py`).
4. Adds a single `/` route that serves `static/index.html` — the frontend.

```python
def create_app() -> Flask:
    app = Flask(__name__, static_folder="static")
    init_db()
    app.register_blueprint(api)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    return app
```

### routes.py — the API endpoints

A **Blueprint** is Flask's way of grouping related routes. The `api` blueprint has the prefix `/api`, so all task routes live under `/api/tasks`.

| Method | URL | What it does | Success code |
|---|---|---|---|
| GET | /api/tasks | Returns a JSON array of all tasks | 200 |
| POST | /api/tasks | Creates a new task from the JSON body | 201 |
| GET | /api/tasks/`<id>` | Returns one task by its numeric id | 200 |
| PUT | /api/tasks/`<id>` | Partially updates a task | 200 |
| DELETE | /api/tasks/`<id>` | Deletes a task | 200 |

### Input validation

Before any data reaches the database, `_validate_task_fields()` checks:

- `title` is present and not just whitespace (on create)
- `priority` is exactly one of: `low`, `medium`, `high`
- `status` is exactly one of: `open`, `done`
- `due_date` matches the pattern `YYYY-MM-DD` (four digit year, two digit month, two digit day)

If validation fails, the server returns HTTP **400 Bad Request** with a JSON body describing what was wrong. The database is never touched.

### HTTP status codes explained

| Code | Meaning | When it is returned |
|---|---|---|
| 200 OK | Success | Listing, fetching, updating, or deleting a task |
| 201 Created | A new resource was made | A task was successfully created |
| 400 Bad Request | The client sent invalid data | Missing title, wrong priority value, bad date format |
| 404 Not Found | The resource does not exist | Trying to fetch/update/delete a task id that is not in the database |

---

## 5. The Frontend (index.html)

The entire user interface is a single HTML file at `static/index.html`. It contains:

- **HTML** — the structure of the page (form, list, filter controls)
- **CSS** — the visual styling (colors, spacing, typography, hover effects)
- **JavaScript** — the behavior (sending requests, rendering task cards, handling button clicks)

No frameworks, no build tools, no external files. Everything loads from one file served by Flask.

### How the JavaScript works

When the page loads, JavaScript immediately calls `GET /api/tasks` and renders the results as cards. All subsequent actions follow the same pattern:

1. User interacts (clicks a button, submits the form).
2. JavaScript gathers the relevant data.
3. JavaScript sends a `fetch()` request to the appropriate API endpoint.
4. When the response arrives, JavaScript updates only the affected part of the page — no full page reload needed.

### Accessibility features

The UI was built to meet **WCAG AA** accessibility standards:

- Every form field has a `<label>` so screen readers announce what it is.
- All interactive elements (buttons, selects, inputs) show a visible outline when focused via keyboard — no mouse required.
- Color contrast between text and background meets the minimum 4.5:1 ratio.
- The page uses semantic HTML elements (`<header>`, `<main>`, `<section>`) so assistive technology can understand the structure.

---

## 6. End-to-End Flow — What Happens When You Use the App

### Opening the app

```
Browser → GET / → Flask serves static/index.html
Page loads → JavaScript → GET /api/tasks → Flask → db.list_tasks() → SQLite
                                         ← JSON array of tasks ←
JavaScript renders task cards on screen
```

### Adding a task

```
User fills form, clicks "Add Task"
JavaScript → POST /api/tasks  body: {"title":"Buy milk","priority":"low"}
                              → routes.create_task()
                                → _validate_task_fields() ✓
                                → db.create_task(data)
                                  → INSERT INTO tasks ... → tasks.db
                                  ← new row dict ←
                              ← JSON {"id":1,"title":"Buy milk",...} 201
JavaScript adds new card to the list (no full page reload)
```

### Marking a task done

```
User clicks "Mark Done" on a card
JavaScript → PUT /api/tasks/1  body: {"status":"done"}
                               → routes.update_task(1)
                                 → _validate_task_fields() ✓
                                 → db.update_task(1, {"status":"done"})
                                   → UPDATE tasks SET status=? WHERE id=? → tasks.db
                                   ← updated row dict ←
                               ← JSON {"id":1,"status":"done",...} 200
JavaScript updates that card's badge and button text
```

### Filtering by status

```
User changes Status filter to "Done"
JavaScript → GET /api/tasks?status=done
                            → routes.list_tasks()
                              → validates "done" is a valid status ✓
                              → db.list_tasks(status="done")
                                → SELECT * FROM tasks WHERE status=? → tasks.db
                                ← matching rows ←
                            ← JSON array of done tasks 200
JavaScript re-renders the list with only those cards
```

### Deleting a task

```
User clicks "Delete" on a card
JavaScript → DELETE /api/tasks/1
                              → routes.delete_task(1)
                                → db.delete_task(1)
                                  → DELETE FROM tasks WHERE id=? → tasks.db
                                  ← rowcount=1 ← (row was found and deleted)
                              ← {"deleted": true} 200
JavaScript fades out and removes the card from the DOM
```

---

## 7. The Test Suite (pytest)

### Why tests?

Tests verify that the API behaves correctly — not just on the happy path (valid input, existing records) but also on edge cases (missing fields, bad values, records that do not exist). They let you change the code confidently: if a test breaks, you know exactly what stopped working.

### How the tests are isolated

A key challenge with database tests is making sure one test does not affect another. This is solved with two pytest fixtures in `conftest.py`:

- **`app` (session scope)** — creates a Flask app pointed at a *temporary* database file (not `tasks.db`). The real database is never touched during tests.
- **`db_reset` (function scope)** — before each test that uses it, runs `DELETE FROM tasks` to clear all rows. This means every test starts from a clean slate.

### What the 24 tests cover

| Group | Tests |
|---|---|
| List tasks | Empty list, tasks appear after creation, filter by open/done status, filter by priority, invalid filter values return 400 |
| Create task | All fields, title-only defaults, missing title, blank title, invalid priority/status/due_date, non-JSON body |
| Get one task | Fetch existing task, fetch non-existent ID → 404 |
| Update task | Partial update (only changed fields change), toggle status, invalid priority on update, non-existent ID → 404 |
| Delete task | Delete existing, delete non-existent → 404, deleted task no longer in list |

### Running the tests

```bash
cd C:\Users\Administrator\task-tracker
.venv\Scripts\pytest tests/ -v
```

---

## 8. How AI Agents Were Used to Build This

This project was built using **Claude Code** with a multi-agent workflow. Instead of one AI doing everything sequentially, the work was split into specialized agents that ran in parallel or in sequence.

### What is an agent?

An agent is a Claude AI session configured with a specific role, a set of tools it can use, and instructions about how to approach its job. Each agent in this project was defined as a Markdown file in `.claude/agents/`.

### The agents and what they did

| Agent | Model | Role | What it produced |
|---|---|---|---|
| `backend-api` | Claude Sonnet | Backend engineer — builds APIs and databases | `db.py`, `routes.py`, `app.py`, `requirements.txt` |
| `frontend-ui` | Claude Sonnet | Frontend engineer — builds user interfaces | `static/index.html` |
| `test-writer` | Claude Haiku | Test engineer — writes and runs test suites | `tests/conftest.py`, `tests/test_api.py` |
| `docs-writer` | Claude Haiku | Technical writer — produces documentation | `README.md` (this file) |
| `security-reviewer` | Claude Opus | Security engineer — reviews code for vulnerabilities | Security findings and fixes |

### Why split into agents?

1. **Parallelism** — the backend and frontend agents ran at the same time, cutting total build time roughly in half.
2. **Specialization** — each agent was given only the tools and context it needed. The test-writer only needed to read and run code, not write production files.
3. **Cost efficiency** — simpler tasks (tests, docs) used the smaller, faster Haiku model. Complex tasks (backend logic, security review) used the more capable Sonnet/Opus models.
4. **Quality** — a dedicated security reviewer catches issues that a general-purpose agent might overlook.

### The build sequence

```
Step 1 (parallel):
  backend-api agent ──┐
                      ├── both run at the same time
  frontend-ui agent ──┘

Step 2 (sequential):
  Set up .venv, install Flask + pytest

Step 3:
  test-writer agent → writes tests → runs them → fixes failures → all pass

Step 4:
  security-reviewer agent → reviews code → reports findings

Step 5:
  docs-writer agent → produces this README
```

---

## 9. Project File Map

```
task-tracker/
│
├── app.py              Flask app factory. Entry point. Wires everything together.
├── db.py               All database logic. The only file that talks to SQLite.
├── routes.py           HTTP route handlers. Thin — just validate, call db, return JSON.
├── requirements.txt    Python package dependencies (Flask, pytest).
│
├── static/
│   └── index.html      The entire frontend: HTML structure + CSS styles + JS behavior.
│
├── tests/
│   ├── __init__.py     Empty — marks the folder as a Python package for pytest.
│   ├── conftest.py     Shared pytest fixtures: test app, test client, db isolation.
│   └── test_api.py     24 tests covering all endpoints, happy paths, and edge cases.
│
├── .claude/
│   └── agents/         Agent definition files (role, model, tools for each AI agent).
│       ├── backend-api.md
│       ├── frontend-ui.md
│       ├── test-writer.md
│       ├── docs-writer.md
│       └── security-reviewer.md
│
├── CLAUDE.md           Project conventions read by Claude Code automatically.
├── .gitignore          Tells Git to ignore .venv, __pycache__, and tasks.db.
└── tasks.db            Created automatically when the app first runs. Not in Git.
```

---

## 10. Setup & Running the App

### First-time setup

```bash
# 1. Go to the project folder
cd C:\Users\Administrator\task-tracker

# 2. Create a virtual environment (Python 3.13 installed at Program Files\Python313)
"C:\Program Files\Python313\python" -m venv .venv

# 3. Install dependencies
.venv\Scripts\pip install flask pytest
```

### Start the app

```bash
cd C:\Users\Administrator\task-tracker
.venv\Scripts\python app.py
```

Open your browser to `http://<machine-ip>:5000`

### Run the tests

```bash
cd C:\Users\Administrator\task-tracker
.venv\Scripts\pytest tests/ -v
```

Expected output:
```
24 passed in 0.62s
```

### Stop the app

Press `Ctrl+C` in the terminal where the app is running.
