# Task Tracker API

A Flask REST API backed by SQLite for creating and managing tasks. The server also serves a static frontend at `/`.

---

## Setup

```bat
"C:\Program Files\Python313\python" -m venv .venv
.venv\Scripts\pip install -r requirements.txt
```

`requirements.txt` includes `pytest>=8.0`, so no extra install is needed to run tests.

---

## Running the app

```bat
cd C:\Users\Administrator\task-tracker
.venv\Scripts\python app.py
```

Open <http://localhost:5000> in a browser. The SQLite database (`tasks.db`) is created automatically on first run.

---

## Running tests

```bat
.venv\Scripts\pytest tests/ -v
```

---

## API endpoint reference

All endpoints are prefixed with `/api`. Request and response bodies are JSON.

| Method | Path | Request body | Success | Error responses |
|--------|------|-------------|---------|-----------------|
| `GET` | `/api/tasks` | — | `200` array of task objects | `400` invalid `status`/`priority` query param |
| `POST` | `/api/tasks` | task fields (see below) | `201` created task object | `400` invalid/missing fields |
| `GET` | `/api/tasks/<id>` | — | `200` task object | `404` task not found |
| `PUT` | `/api/tasks/<id>` | any subset of task fields | `200` updated task object | `400` invalid fields · `404` task not found |
| `DELETE` | `/api/tasks/<id>` | — | `200` `{"deleted": true}` | `404` task not found |

`GET /api/tasks` accepts optional query parameters `?status=` and `?priority=` to filter results.

### Task object

| Field | Type | Notes |
|-------|------|-------|
| `id` | `integer` | Auto-assigned, read-only |
| `title` | `string` | Required on create |
| `description` | `string` | Defaults to `""` |
| `priority` | `string` | Defaults to `"medium"` |
| `status` | `string` | Defaults to `"open"` |
| `due_date` | `string \| null` | Defaults to `null` |
| `created_at` | `string` | UTC timestamp, set by server |

### Field constraints

| Field | Required | Allowed values / format |
|-------|----------|------------------------|
| `title` | Yes (create) · non-empty if supplied (update) | Any non-empty string |
| `priority` | No | `"low"`, `"medium"`, `"high"` |
| `status` | No | `"open"`, `"done"` |
| `due_date` | No | `"YYYY-MM-DD"` or `null` |
| `description` | No | Any string |
| `created_at` | — | Server-assigned; format `YYYY-MM-DDTHH:MM:SSZ` (UTC) |

### Error response shapes

Validation errors return an `errors` array:

```json
{ "errors": ["title is required and must be non-empty", "priority must be one of: high, low, medium"] }
```

Not-found and single-message errors return an `error` string:

```json
{ "error": "task not found" }
```

### Example requests

```bash
# Create a task
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{"title": "Write docs", "priority": "high", "due_date": "2026-12-01"}'

# List only open tasks
curl "http://localhost:5000/api/tasks?status=open"

# Mark a task done
curl -X PUT http://localhost:5000/api/tasks/1 \
  -H "Content-Type: application/json" \
  -d '{"status": "done"}'

# Delete a task
curl -X DELETE http://localhost:5000/api/tasks/1
```
