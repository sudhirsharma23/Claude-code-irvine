import os
from flask import Flask, send_from_directory
from db import init_db
from routes import api


def create_app() -> Flask:
    app = Flask(__name__, static_folder="static")

    init_db()

    app.register_blueprint(api)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    return app


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", debug=True)
