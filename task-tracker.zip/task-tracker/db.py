import sqlite3
import os
from datetime import datetime, timezone

DB_PATH = os.path.join(os.path.dirname(__file__), "tasks.db")

VALID_PRIORITIES = {"low", "medium", "high"}
VALID_STATUSES = {"open", "done"}


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                title       TEXT    NOT NULL,
                description TEXT    NOT NULL DEFAULT '',
                priority    TEXT    NOT NULL DEFAULT 'medium',
                status      TEXT    NOT NULL DEFAULT 'open',
                due_date    TEXT,
                created_at  TEXT    NOT NULL
            )
            """
        )
        conn.commit()


def _row_to_dict(row: sqlite3.Row) -> dict:
    return dict(row)


def list_tasks(*, status: str = None, priority: str = None) -> list[dict]:
    query = "SELECT * FROM tasks WHERE 1=1"
    params = []
    if status:
        query += " AND status = ?"
        params.append(status)
    if priority:
        query += " AND priority = ?"
        params.append(priority)
    query += " ORDER BY id"
    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
    return [_row_to_dict(r) for r in rows]


def create_task(data: dict) -> dict:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    with get_db() as conn:
        cursor = conn.execute(
            """
            INSERT INTO tasks (title, description, priority, status, due_date, created_at)
            VALUES (:title, :description, :priority, :status, :due_date, :created_at)
            """,
            {
                "title": data["title"],
                "description": data.get("description", ""),
                "priority": data.get("priority", "medium"),
                "status": data.get("status", "open"),
                "due_date": data.get("due_date"),
                "created_at": now,
            },
        )
        conn.commit()
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return _row_to_dict(row)


def get_task(task_id: int) -> dict | None:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return _row_to_dict(row) if row else None


def update_task(task_id: int, data: dict) -> dict | None:
    allowed = {"title", "description", "priority", "status", "due_date"}
    fields = {k: v for k, v in data.items() if k in allowed}
    if not fields:
        return get_task(task_id)
    set_clause = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [task_id]
    with get_db() as conn:
        rowcount = conn.execute(
            f"UPDATE tasks SET {set_clause} WHERE id = ?", values
        ).rowcount
        conn.commit()
        if rowcount == 0:
            return None
        row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return _row_to_dict(row)


def delete_task(task_id: int) -> bool:
    with get_db() as conn:
        rowcount = conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,)).rowcount
        conn.commit()
    return rowcount > 0
