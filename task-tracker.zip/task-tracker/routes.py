import re
from flask import Blueprint, request, jsonify
import db

api = Blueprint("api", __name__, url_prefix="/api")

VALID_PRIORITIES = {"low", "medium", "high"}
VALID_STATUSES = {"open", "done"}
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _validate_task_fields(data: dict, require_title: bool = True) -> list[str]:
    """Return a list of validation error messages (empty = valid)."""
    errors = []
    if require_title:
        title = data.get("title")
        if not title or not str(title).strip():
            errors.append("title is required and must be non-empty")
    elif "title" in data:
        if not str(data["title"]).strip():
            errors.append("title must be non-empty")

    if "priority" in data and data["priority"] not in VALID_PRIORITIES:
        errors.append(f"priority must be one of: {', '.join(sorted(VALID_PRIORITIES))}")

    if "status" in data and data["status"] not in VALID_STATUSES:
        errors.append(f"status must be one of: {', '.join(sorted(VALID_STATUSES))}")

    if "due_date" in data and data["due_date"] is not None:
        if not DATE_RE.match(str(data["due_date"])):
            errors.append("due_date must be in YYYY-MM-DD format")

    return errors


@api.get("/tasks")
def list_tasks():
    status = request.args.get("status")
    priority = request.args.get("priority")

    if status and status not in VALID_STATUSES:
        return jsonify({"error": f"status must be one of: {', '.join(sorted(VALID_STATUSES))}"}), 400
    if priority and priority not in VALID_PRIORITIES:
        return jsonify({"error": f"priority must be one of: {', '.join(sorted(VALID_PRIORITIES))}"}), 400

    tasks = db.list_tasks(status=status, priority=priority)
    return jsonify(tasks), 200


@api.post("/tasks")
def create_task():
    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"error": "request body must be valid JSON"}), 400

    errors = _validate_task_fields(data, require_title=True)
    if errors:
        return jsonify({"errors": errors}), 400

    task = db.create_task(data)
    return jsonify(task), 201


@api.get("/tasks/<int:id>")
def get_task(id: int):
    task = db.get_task(id)
    if task is None:
        return jsonify({"error": "task not found"}), 404
    return jsonify(task), 200


@api.put("/tasks/<int:id>")
def update_task(id: int):
    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"error": "request body must be valid JSON"}), 400

    errors = _validate_task_fields(data, require_title=False)
    if errors:
        return jsonify({"errors": errors}), 400

    task = db.update_task(id, data)
    if task is None:
        return jsonify({"error": "task not found"}), 404
    return jsonify(task), 200


@api.delete("/tasks/<int:id>")
def delete_task(id: int):
    deleted = db.delete_task(id)
    if not deleted:
        return jsonify({"error": "task not found"}), 404
    return jsonify({"deleted": True}), 200
