import sqlite3
import pytest
import db as db_module
from app import create_app


@pytest.fixture(scope="session")
def app(tmp_path_factory):
    """Create Flask app pointed at a temporary SQLite database."""
    db_path = str(tmp_path_factory.mktemp("data") / "test_tasks.db")
    # Patch the module-level DB_PATH before create_app() calls init_db()
    db_module.DB_PATH = db_path
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    yield flask_app
    # tmp_path_factory cleans up automatically


@pytest.fixture(scope="session")
def client(app):
    """Return a Flask test client."""
    return app.test_client()


@pytest.fixture(scope="function")
def db_reset(app):
    """Truncate the tasks table before each test that requests this fixture."""
    with sqlite3.connect(db_module.DB_PATH) as conn:
        conn.execute("DELETE FROM tasks")
        conn.commit()
    yield
