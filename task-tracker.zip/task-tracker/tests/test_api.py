"""
Pytest suite for the Flask task-tracker API.
Every test that mutates state uses the db_reset fixture for isolation.
"""

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def post_task(client, **kwargs):
    """POST /api/tasks with the given keyword arguments as JSON body."""
    return client.post("/api/tasks", json=kwargs)


def create_sample(client, title="Test task", **kwargs):
    """Create a task and return the parsed JSON body (asserts 201)."""
    resp = post_task(client, title=title, **kwargs)
    assert resp.status_code == 201
    return resp.get_json()


# ===========================================================================
# List tasks
# ===========================================================================

class TestListTasks:
    def test_empty_list(self, client, db_reset):
        resp = client.get("/api/tasks")
        assert resp.status_code == 200
        assert resp.get_json() == []

    def test_returns_tasks_after_creation(self, client, db_reset):
        create_sample(client, title="Task A")
        create_sample(client, title="Task B")
        resp = client.get("/api/tasks")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 2
        titles = {t["title"] for t in data}
        assert titles == {"Task A", "Task B"}

    def test_filter_status_open(self, client, db_reset):
        create_sample(client, title="Open task", status="open")
        done_task = create_sample(client, title="Done task")
        # mark it done via PUT
        client.put(f"/api/tasks/{done_task['id']}", json={"status": "done"})

        resp = client.get("/api/tasks?status=open")
        assert resp.status_code == 200
        data = resp.get_json()
        assert all(t["status"] == "open" for t in data)
        assert any(t["title"] == "Open task" for t in data)

    def test_filter_status_done(self, client, db_reset):
        create_sample(client, title="Open task")
        done_task = create_sample(client, title="Done task")
        client.put(f"/api/tasks/{done_task['id']}", json={"status": "done"})

        resp = client.get("/api/tasks?status=done")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 1
        assert data[0]["status"] == "done"
        assert data[0]["title"] == "Done task"

    def test_filter_priority_high(self, client, db_reset):
        create_sample(client, title="High priority", priority="high")
        create_sample(client, title="Low priority", priority="low")

        resp = client.get("/api/tasks?priority=high")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 1
        assert data[0]["priority"] == "high"

    def test_invalid_status_filter_returns_400(self, client, db_reset):
        resp = client.get("/api/tasks?status=invalid")
        assert resp.status_code == 400
        body = resp.get_json()
        assert "error" in body

    def test_invalid_priority_filter_returns_400(self, client, db_reset):
        resp = client.get("/api/tasks?priority=urgent")
        assert resp.status_code == 400
        body = resp.get_json()
        assert "error" in body


# ===========================================================================
# Create task
# ===========================================================================

class TestCreateTask:
    def test_happy_path_all_fields(self, client, db_reset):
        resp = post_task(
            client,
            title="Full task",
            description="A description",
            priority="high",
            status="open",
            due_date="2025-12-31",
        )
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["title"] == "Full task"
        assert data["description"] == "A description"
        assert data["priority"] == "high"
        assert data["status"] == "open"
        assert data["due_date"] == "2025-12-31"
        assert "id" in data
        assert "created_at" in data

    def test_happy_path_title_only_defaults(self, client, db_reset):
        resp = post_task(client, title="Minimal task")
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["title"] == "Minimal task"
        assert data["description"] == ""
        assert data["priority"] == "medium"
        assert data["status"] == "open"
        assert data["due_date"] is None

    def test_missing_title_returns_400(self, client, db_reset):
        resp = client.post("/api/tasks", json={"description": "no title"})
        assert resp.status_code == 400

    def test_empty_title_returns_400(self, client, db_reset):
        resp = post_task(client, title="   ")
        assert resp.status_code == 400

    def test_invalid_priority_returns_400(self, client, db_reset):
        resp = post_task(client, title="Task", priority="urgent")
        assert resp.status_code == 400

    def test_invalid_status_returns_400(self, client, db_reset):
        resp = post_task(client, title="Task", status="pending")
        assert resp.status_code == 400

    def test_invalid_due_date_format_returns_400(self, client, db_reset):
        resp = post_task(client, title="Task", due_date="31-12-2025")
        assert resp.status_code == 400

    def test_non_json_body_returns_400(self, client, db_reset):
        resp = client.post(
            "/api/tasks",
            data="not json",
            content_type="text/plain",
        )
        assert resp.status_code == 400


# ===========================================================================
# Get task
# ===========================================================================

class TestGetTask:
    def test_existing_task_returns_200(self, client, db_reset):
        created = create_sample(
            client,
            title="Fetch me",
            description="detail",
            priority="low",
        )
        resp = client.get(f"/api/tasks/{created['id']}")
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["id"] == created["id"]
        assert data["title"] == "Fetch me"
        assert data["description"] == "detail"
        assert data["priority"] == "low"

    def test_nonexistent_id_returns_404(self, client, db_reset):
        resp = client.get("/api/tasks/999999")
        assert resp.status_code == 404
        body = resp.get_json()
        assert "error" in body


# ===========================================================================
# Update task
# ===========================================================================

class TestUpdateTask:
    def test_partial_update_title_only(self, client, db_reset):
        created = create_sample(
            client,
            title="Old title",
            description="keep me",
            priority="low",
            status="open",
        )
        resp = client.put(
            f"/api/tasks/{created['id']}", json={"title": "New title"}
        )
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["title"] == "New title"
        # Other fields must remain unchanged
        assert data["description"] == "keep me"
        assert data["priority"] == "low"
        assert data["status"] == "open"

    def test_toggle_status_open_to_done(self, client, db_reset):
        created = create_sample(client, title="Toggle me")
        assert created["status"] == "open"

        resp = client.put(
            f"/api/tasks/{created['id']}", json={"status": "done"}
        )
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "done"

    def test_invalid_priority_on_update_returns_400(self, client, db_reset):
        created = create_sample(client, title="Task")
        resp = client.put(
            f"/api/tasks/{created['id']}", json={"priority": "critical"}
        )
        assert resp.status_code == 400

    def test_nonexistent_id_returns_404(self, client, db_reset):
        resp = client.put("/api/tasks/999999", json={"title": "Ghost"})
        assert resp.status_code == 404
        body = resp.get_json()
        assert "error" in body


# ===========================================================================
# Delete task
# ===========================================================================

class TestDeleteTask:
    def test_existing_task_returns_200_deleted_true(self, client, db_reset):
        created = create_sample(client, title="Delete me")
        resp = client.delete(f"/api/tasks/{created['id']}")
        assert resp.status_code == 200
        assert resp.get_json() == {"deleted": True}

    def test_nonexistent_id_returns_404(self, client, db_reset):
        resp = client.delete("/api/tasks/999999")
        assert resp.status_code == 404
        body = resp.get_json()
        assert "error" in body

    def test_deleted_task_gone_from_list(self, client, db_reset):
        created = create_sample(client, title="Ephemeral")
        client.delete(f"/api/tasks/{created['id']}")

        resp = client.get("/api/tasks")
        assert resp.status_code == 200
        ids = [t["id"] for t in resp.get_json()]
        assert created["id"] not in ids
